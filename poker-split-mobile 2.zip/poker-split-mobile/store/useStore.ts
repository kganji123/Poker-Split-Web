import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Group, Game, User, Stats, GameRound } from '@/types';

interface AppState {
  user: User | null;
  groups: Group[];
  games: Game[];
  activeGame: string | null;
  isLoading: boolean;
  error: string | null;
  
  // User actions
  setUser: (user: User | null) => void;
  
  // Group actions
  createGroup: (group: Omit<Group, 'id' | 'createdAt'>) => void;
  updateGroup: (groupId: string, updates: Partial<Omit<Group, 'id'>>) => void;
  deleteGroup: (groupId: string) => void;
  
  // Game actions
  createGame: (game: Omit<Game, 'id' | 'createdAt' | 'isActive'>) => void;
  updateGame: (gameId: string, updates: Partial<Omit<Game, 'id'>>) => void;
  endGame: (gameId: string) => void;
  deleteGame: (gameId: string) => void;
  setActiveGame: (gameId: string | null) => void;
  
  // Player actions
  updatePlayerBuyIn: (gameId: string, userId: string, amount: number) => void;
  addRebuy: (gameId: string, userId: string, amount: number) => void;
  updateFinalChips: (gameId: string, userId: string, amount: number) => void;
  
  // Settlement actions
  calculateSettlements: (gameId: string) => void;
  markSettlementAsSettled: (gameId: string, fromId: string, toId: string) => void;
  
  // Stats
  getUserStats: (userId: string) => Stats;
  getLeaderboard: () => Array<{userId: string; name: string; avatar?: string; totalWinnings: number; gamesPlayed: number; winRate: number}>;
  
  // App state
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
}

const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      user: null,
      groups: [],
      games: [],
      activeGame: null,
      isLoading: false,
      error: null,
      
      setUser: (user) => set({ user }),
      
      createGroup: (groupData) => {
        const newGroup: Group = {
          ...groupData,
          id: Date.now().toString(),
          createdAt: Date.now(),
          buyInAmount: groupData.buyInAmount || 2000, // Default to 2000 if not specified
        };
        set((state) => ({ groups: [...state.groups, newGroup] }));
      },
      
      updateGroup: (groupId, updates) => {
        set((state) => ({
          groups: state.groups.map((group) => 
            group.id === groupId ? { ...group, ...updates } : group
          ),
        }));
      },
      
      deleteGroup: (groupId) => {
        set((state) => ({
          groups: state.groups.filter((group) => group.id !== groupId),
          // Also delete associated games
          games: state.games.filter((game) => game.groupId !== groupId),
        }));
      },
      
      createGame: (gameData) => {
        const newGame: Game = {
          ...gameData,
          id: Date.now().toString(),
          createdAt: Date.now(),
          isActive: true,
          rounds: [],
        };
        set((state) => ({ 
          games: [...state.games, newGame],
          activeGame: newGame.id
        }));
      },
      
      updateGame: (gameId, updates) => {
        set((state) => ({
          games: state.games.map((game) => 
            game.id === gameId ? { ...game, ...updates } : game
          ),
        }));
      },
      
      endGame: (gameId) => {
        const { calculateSettlements } = get();
        calculateSettlements(gameId);
        
        set((state) => ({
          games: state.games.map((game) => 
            game.id === gameId 
              ? { ...game, isActive: false, endedAt: Date.now() } 
              : game
          ),
          activeGame: null,
        }));
      },
      
      deleteGame: (gameId) => {
        set((state) => ({
          games: state.games.filter((game) => game.id !== gameId),
          activeGame: state.activeGame === gameId ? null : state.activeGame,
        }));
      },
      
      setActiveGame: (gameId) => {
        set({ activeGame: gameId });
      },
      
      updatePlayerBuyIn: (gameId, userId, amount) => {
        set((state) => ({
          games: state.games.map((game) => {
            if (game.id !== gameId) return game;
            
            return {
              ...game,
              players: game.players.map((player) => 
                player.userId === userId 
                  ? { ...player, initialBuyIn: amount } 
                  : player
              ),
            };
          }),
        }));
      },
      
      addRebuy: (gameId, userId, amount) => {
        const timestamp = Date.now();
        
        set((state) => ({
          games: state.games.map((game) => {
            if (game.id !== gameId) return game;
            
            return {
              ...game,
              players: game.players.map((player) => {
                if (player.userId !== userId) return player;
                
                return {
                  ...player,
                  rebuys: [...player.rebuys, { amount, timestamp }],
                };
              }),
            };
          }),
        }));
      },
      
      updateFinalChips: (gameId, userId, amount) => {
        set((state) => ({
          games: state.games.map((game) => {
            if (game.id !== gameId) return game;
            
            return {
              ...game,
              players: game.players.map((player) => 
                player.userId === userId 
                  ? { ...player, finalChips: amount } 
                  : player
              ),
            };
          }),
        }));
      },
      
      calculateSettlements: (gameId) => {
        set((state) => {
          const game = state.games.find((g) => g.id === gameId);
          if (!game) return state;
          
          const group = state.groups.find((g) => g.id === game.groupId);
          if (!group) return state;
          
          // Calculate net results for each player
          const playersWithResults = game.players.map((player) => {
            const totalBuyIn = player.initialBuyIn + 
              player.rebuys.reduce((sum, rebuy) => sum + rebuy.amount, 0);
            
            const netChips = player.finalChips - totalBuyIn;
            const netResult = netChips * (group.chipValue / 1000); // Convert to dollars
            
            return {
              ...player,
              netResult,
            };
          });
          
          // Calculate settlements
          const settlements = [];
          const debtors = playersWithResults.filter((p) => p.netResult! < 0)
            .sort((a, b) => a.netResult! - b.netResult!);
          const creditors = playersWithResults.filter((p) => p.netResult! > 0)
            .sort((a, b) => b.netResult! - a.netResult!);
          
          // Simple settlement algorithm
          for (const debtor of debtors) {
            let remainingDebt = Math.abs(debtor.netResult!);
            
            for (let i = 0; i < creditors.length && remainingDebt > 0; i++) {
              const creditor = creditors[i];
              const remainingCredit = creditor.netResult!;
              
              if (remainingCredit <= 0) continue;
              
              const transferAmount = Math.min(remainingDebt, remainingCredit);
              
              if (transferAmount > 0) {
                settlements.push({
                  fromPlayerId: debtor.userId,
                  toPlayerId: creditor.userId,
                  amount: parseFloat(transferAmount.toFixed(2)),
                  settled: false,
                });
                
                remainingDebt -= transferAmount;
                creditors[i] = { ...creditor, netResult: remainingCredit - transferAmount };
              }
            }
          }
          
          return {
            games: state.games.map((g) => 
              g.id === gameId 
                ? { 
                    ...g, 
                    players: playersWithResults,
                    settlements,
                  } 
                : g
            ),
          };
        });
      },
      
      markSettlementAsSettled: (gameId, fromId, toId) => {
        set((state) => ({
          games: state.games.map((game) => {
            if (game.id !== gameId) return game;
            
            return {
              ...game,
              settlements: game.settlements?.map((settlement) => 
                settlement.fromPlayerId === fromId && settlement.toPlayerId === toId
                  ? { ...settlement, settled: true }
                  : settlement
              ),
            };
          }),
        }));
      },
      
      getUserStats: (userId) => {
        const { games } = get();
        const userGames = games.filter((game) => 
          game.players.some((player) => player.userId === userId)
        );
        
        if (userGames.length === 0) {
          return {
            gamesPlayed: 0,
            totalWinnings: 0,
            biggestWin: 0,
            biggestLoss: 0,
            winRate: 0,
          };
        }
        
        const results = userGames.map((game) => {
          const player = game.players.find((p) => p.userId === userId);
          return player?.netResult || 0;
        });
        
        const wins = results.filter((result) => result > 0);
        
        return {
          gamesPlayed: userGames.length,
          totalWinnings: results.reduce((sum, result) => sum + result, 0),
          biggestWin: Math.max(0, ...results),
          biggestLoss: Math.abs(Math.min(0, ...results)),
          winRate: wins.length / userGames.length,
        };
      },
      
      getLeaderboard: () => {
        const { games } = get();
        const completedGames = games.filter(game => !game.isActive);
        
        // Create a map to track player stats across all games
        const playerStats = new Map();
        
        // Process all completed games
        completedGames.forEach(game => {
          game.players.forEach(player => {
            if (player.netResult === undefined) return;
            
            // Get or initialize player stats
            const stats = playerStats.get(player.userId) || {
              userId: player.userId,
              name: player.name,
              avatar: player.avatar,
              totalWinnings: 0,
              gamesPlayed: 0,
              wins: 0,
            };
            
            // Update stats
            stats.totalWinnings += player.netResult;
            stats.gamesPlayed += 1;
            if (player.netResult > 0) stats.wins += 1;
            
            // Save updated stats
            playerStats.set(player.userId, stats);
          });
        });
        
        // Convert map to array and calculate win rate
        const leaderboardData = Array.from(playerStats.values()).map(stats => ({
          ...stats,
          winRate: stats.gamesPlayed > 0 ? stats.wins / stats.gamesPlayed : 0,
        }));
        
        // Sort by total winnings (descending)
        return leaderboardData.sort((a, b) => b.totalWinnings - a.totalWinnings);
      },
      
      setLoading: (isLoading) => set({ isLoading }),
      setError: (error) => set({ error }),
    }),
    {
      name: 'poker-split-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        user: state.user,
        groups: state.groups,
        games: state.games,
      }),
    }
  )
);

export default useStore;