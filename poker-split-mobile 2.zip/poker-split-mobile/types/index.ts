export type User = {
  id: string;
  name: string;
  email?: string;
  avatar?: string;
};

export type Group = {
  id: string;
  name: string;
  adminId: string;
  chipValue: number; // Value of 1 chip in dollars
  members: string[]; // Array of user IDs
  createdAt: number;
  buyInAmount?: number; // Default amount of chips for buy-in (default: 2000)
};

export type Player = {
  userId: string;
  name: string;
  avatar?: string;
  initialBuyIn: number; // Chips
  rebuys: Rebuy[];
  finalChips: number;
  netResult?: number; // Calculated field
};

export type Rebuy = {
  amount: number; // Chips
  timestamp: number;
};

export type GameRound = {
  id: string;
  timestamp: number;
  winnerId: string;
  handType?: string;
};

export type Game = {
  id: string;
  groupId: string;
  name: string;
  date: number;
  isActive: boolean;
  players: Player[];
  settlements?: Settlement[];
  rounds?: GameRound[];
  createdAt: number;
  endedAt?: number;
};

export type Settlement = {
  fromPlayerId: string;
  toPlayerId: string;
  amount: number; // In dollars
  settled: boolean;
};

export type Stats = {
  gamesPlayed: number;
  totalWinnings: number;
  biggestWin: number;
  biggestLoss: number;
  winRate: number;
};