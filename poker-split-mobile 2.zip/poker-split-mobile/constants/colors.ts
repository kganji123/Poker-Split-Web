export default {
  dark: {
    background: '#0A1F1C', // Dark poker table green
    card: '#122C28', // Slightly lighter poker green
    cardAlt: '#1A3834', // Accent poker green
    text: '#FFFFFF',
    textSecondary: '#AAAAAA',
    primary: '#4CAF50', // Poker table green
    secondary: '#D32F2F', // Card red
    success: '#66BB6A', // Light green
    warning: '#FFC107',
    error: '#F44336',
    border: '#2A4A45', // Darker border for poker theme
    chip: '#F5F5F5', // White chip
    chipGold: '#FFD700', // Gold chip
    chipBlack: '#333333', // Black chip
    chipRed: '#D32F2F', // Red chip
    chipBlue: '#1976D2', // Blue chip
    overlay: 'rgba(0, 0, 0, 0.7)',
    shadow: '#000000',
    inactive: '#666666',
    highlight: '#2C423F', // Highlighted area
    gold: '#FFD700', // Gold for first place
    silver: '#C0C0C0', // Silver for second place
    bronze: '#CD7F32', // Bronze for third place
  }
};