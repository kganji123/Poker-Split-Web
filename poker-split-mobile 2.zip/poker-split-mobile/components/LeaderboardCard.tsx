import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import colors from '@/constants/colors';
import Avatar from './Avatar';

interface LeaderboardPlayerProps {
  rank: number;
  name: string;
  avatar?: string;
  winnings: number;
  gamesPlayed: number;
  winRate: number;
}

const LeaderboardCard: React.FC<LeaderboardPlayerProps> = ({
  rank,
  name,
  avatar,
  winnings,
  gamesPlayed,
  winRate,
}) => {
  // Determine rank color
  const getRankColor = () => {
    switch (rank) {
      case 1:
        return colors.dark.gold;
      case 2:
        return colors.dark.silver;
      case 3:
        return colors.dark.bronze;
      default:
        return colors.dark.textSecondary;
    }
  };

  const rankColor = getRankColor();

  return (
    <View style={styles.container}>
      <View style={[styles.rankContainer, { borderColor: rankColor }]}>
        <Text style={[styles.rankText, { color: rankColor }]}>{rank}</Text>
      </View>
      
      <Avatar name={name} imageUrl={avatar} size={40} style={styles.avatar} />
      
      <View style={styles.infoContainer}>
        <Text style={styles.name}>{name}</Text>
        <View style={styles.statsRow}>
          <Text style={styles.statText}>{gamesPlayed} games</Text>
          <Text style={styles.statText}>{(winRate * 100).toFixed(0)}% win rate</Text>
        </View>
      </View>
      
      <View style={styles.winningsContainer}>
        <Text style={[
          styles.winnings, 
          winnings >= 0 ? styles.positive : styles.negative
        ]}>
          {winnings >= 0 ? '+' : ''}{winnings.toFixed(2)}
        </Text>
        <Text style={styles.currency}>$</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 12,
    marginVertical: 6,
  },
  rankContainer: {
    width: 30,
    height: 30,
    borderRadius: 15,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  rankText: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  avatar: {
    marginRight: 12,
  },
  infoContainer: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  statText: {
    fontSize: 12,
    color: colors.dark.textSecondary,
  },
  winningsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  winnings: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  positive: {
    color: colors.dark.success,
  },
  negative: {
    color: colors.dark.secondary,
  },
  currency: {
    fontSize: 12,
    color: colors.dark.textSecondary,
    marginLeft: 2,
  },
});

export default LeaderboardCard;