import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Modal, 
  TouchableOpacity, 
  KeyboardAvoidingView, 
  Platform,
  ScrollView
} from 'react-native';
import { X } from 'lucide-react-native';
import colors from '@/constants/colors';
import Input from './Input';
import Button from './Button';

interface EditPlayerModalProps {
  visible: boolean;
  player: { userId: string; name: string; avatar?: string } | null;
  onClose: () => void;
  onSave: (player: { userId: string; name: string; avatar?: string }) => void;
}

const EditPlayerModal: React.FC<EditPlayerModalProps> = ({
  visible,
  player,
  onClose,
  onSave,
}) => {
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (player) {
      setName(player.name);
    }
  }, [player]);

  const handleSave = () => {
    if (!player) return;
    
    if (!name.trim()) {
      setError('Player name is required');
      return;
    }

    onSave({
      userId: player.userId,
      name: name.trim(),
      avatar: player.avatar,
    });
    
    setError('');
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.overlay}>
          <View style={styles.modalContent}>
            <View style={styles.header}>
              <Text style={styles.title}>Edit Player</Text>
              <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                <X size={24} color={colors.dark.text} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.form}>
              <Input
                label="Player Name"
                value={name}
                onChangeText={setName}
                placeholder="Enter player name"
                autoCapitalize="words"
                error={error}
              />

              <Text style={styles.infoText}>
                This will only change the player's name for this game and won't affect their profile.
              </Text>

              <View style={styles.buttonContainer}>
                <Button
                  title="Save Changes"
                  onPress={handleSave}
                  style={styles.saveButton}
                />
                <Button
                  title="Cancel"
                  onPress={onClose}
                  variant="ghost"
                />
              </View>
            </ScrollView>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.dark.background,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 16,
    paddingBottom: 24,
    maxHeight: '80%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  closeButton: {
    padding: 4,
  },
  form: {
    marginTop: 16,
  },
  infoText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginVertical: 16,
    lineHeight: 20,
  },
  buttonContainer: {
    marginTop: 16,
  },
  saveButton: {
    marginBottom: 12,
  },
});

export default EditPlayerModal;