import React from 'react';
import { View, Text, StyleSheet, Image, StyleProp, ViewStyle } from 'react-native';
import colors from '@/constants/colors';

interface AvatarProps {
  name: string;
  imageUrl?: string;
  size?: number;
  style?: StyleProp<ViewStyle>;
}

const Avatar: React.FC<AvatarProps> = ({
  name,
  imageUrl,
  size = 40,
  style,
}) => {
  // Get initials from name
  const getInitials = () => {
    if (!name) return '?';
    
    const nameParts = name.split(' ');
    if (nameParts.length === 1) {
      return nameParts[0].charAt(0).toUpperCase();
    }
    
    return (
      nameParts[0].charAt(0).toUpperCase() + 
      nameParts[nameParts.length - 1].charAt(0).toUpperCase()
    );
  };

  // Generate a consistent color based on name
  const getColor = () => {
    if (!name) return colors.dark.primary;
    
    const charCodes = name.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
    const hue = charCodes % 360;
    
    return `hsl(${hue}, 70%, 60%)`;
  };

  const avatarStyle = {
    width: size,
    height: size,
    borderRadius: size / 2,
    backgroundColor: getColor(),
  };

  const textSize = size * 0.4;

  return (
    <View style={[avatarStyle, styles.container, style]}>
      {imageUrl ? (
        <Image 
          source={{ uri: imageUrl }} 
          style={[avatarStyle, styles.image]} 
          resizeMode="cover"
        />
      ) : (
        <Text style={[styles.text, { fontSize: textSize }]}>
          {getInitials()}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  text: {
    color: colors.dark.text,
    fontWeight: 'bold',
  },
});

export default Avatar;