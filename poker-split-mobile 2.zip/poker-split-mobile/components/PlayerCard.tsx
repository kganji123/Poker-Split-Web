import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ChevronRight } from 'lucide-react-native';
import colors from '@/constants/colors';
import Avatar from './Avatar';
import { Player } from '@/types';

interface PlayerCardProps {
  player: Player;
  chipValue: number;
  onPress?: () => void;
  showResult?: boolean;
}

const PlayerCard: React.FC<PlayerCardProps> = ({
  player,
  chipValue,
  onPress,
  showResult = false,
}) => {
  const totalBuyIn = player.initialBuyIn + 
    player.rebuys.reduce((sum, rebuy) => sum + rebuy.amount, 0);
  
  const netChips = player.finalChips - totalBuyIn;
  const netResult = netChips * (chipValue / 1000); // Convert to dollars
  
  const isPositive = netResult > 0;
  const resultColor = isPositive ? colors.dark.success : colors.dark.error;

  return (
    <TouchableOpacity 
      style={styles.container}
      onPress={onPress}
      disabled={!onPress}
    >
      <View style={styles.avatarContainer}>
        <Avatar name={player.name} imageUrl={player.avatar} size={50} />
      </View>
      
      <View style={styles.infoContainer}>
        <Text style={styles.name}>{player.name}</Text>
        
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statLabel}>Buy-in:</Text>
            <Text style={styles.statValue}>{player.initialBuyIn}</Text>
          </View>
          
          <View style={styles.statItem}>
            <Text style={styles.statLabel}>Rebuys:</Text>
            <Text style={styles.statValue}>{player.rebuys.length}</Text>
          </View>
          
          <View style={styles.statItem}>
            <Text style={styles.statLabel}>Final:</Text>
            <Text style={styles.statValue}>{player.finalChips || '-'}</Text>
          </View>
        </View>
      </View>
      
      {showResult && player.netResult !== undefined && (
        <View style={styles.resultContainer}>
          <Text style={[styles.resultValue, { color: resultColor }]}>
            {isPositive ? '+' : ''}{netResult.toFixed(2)}
          </Text>
          <Text style={styles.resultCurrency}>$</Text>
        </View>
      )}
      
      {onPress && (
        <View style={styles.chevronContainer}>
          <ChevronRight size={20} color={colors.dark.textSecondary} />
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 12,
    marginVertical: 6,
  },
  avatarContainer: {
    marginRight: 12,
  },
  infoContainer: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statLabel: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  statValue: {
    fontSize: 14,
    color: colors.dark.text,
    fontWeight: '500',
  },
  resultContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 8,
  },
  resultValue: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  resultCurrency: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginLeft: 2,
  },
  chevronContainer: {
    marginLeft: 8,
  },
});

export default PlayerCard;