import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Modal, 
  TouchableOpacity, 
  KeyboardAvoidingView, 
  Platform,
  ScrollView
} from 'react-native';
import { X } from 'lucide-react-native';
import colors from '@/constants/colors';
import Input from './Input';
import Button from './Button';

interface AddPlayerModalProps {
  visible: boolean;
  onClose: () => void;
  onAddPlayer: (name: string, email?: string) => void;
}

const AddPlayerModal: React.FC<AddPlayerModalProps> = ({
  visible,
  onClose,
  onAddPlayer,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleAddPlayer = () => {
    if (!name.trim()) {
      setError('Player name is required');
      return;
    }

    onAddPlayer(name.trim(), email.trim() || undefined);
    setName('');
    setEmail('');
    setError('');
    onClose();
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.overlay}>
          <View style={styles.modalContent}>
            <View style={styles.header}>
              <Text style={styles.title}>Add Player</Text>
              <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                <X size={24} color={colors.dark.text} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.form}>
              <Input
                label="Player Name"
                value={name}
                onChangeText={setName}
                placeholder="Enter player name"
                autoCapitalize="words"
                error={error}
              />

              <Input
                label="Email (Optional)"
                value={email}
                onChangeText={setEmail}
                placeholder="Enter player email"
                keyboardType="email-address"
              />

              <Text style={styles.infoText}>
                Adding a player to your group will allow them to participate in games and track their stats.
              </Text>

              <View style={styles.buttonContainer}>
                <Button
                  title="Add Player"
                  onPress={handleAddPlayer}
                  style={styles.addButton}
                />
                <Button
                  title="Cancel"
                  onPress={onClose}
                  variant="ghost"
                />
              </View>
            </ScrollView>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.dark.background,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 16,
    paddingBottom: 24,
    maxHeight: '80%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  closeButton: {
    padding: 4,
  },
  form: {
    marginTop: 16,
  },
  infoText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginVertical: 16,
    lineHeight: 20,
  },
  buttonContainer: {
    marginTop: 16,
  },
  addButton: {
    marginBottom: 12,
  },
});

export default AddPlayerModal;