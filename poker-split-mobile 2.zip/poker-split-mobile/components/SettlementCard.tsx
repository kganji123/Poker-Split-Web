import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ArrowRight, Check } from 'lucide-react-native';
import colors from '@/constants/colors';
import Avatar from './Avatar';
import { Settlement } from '@/types';

interface SettlementCardProps {
  settlement: Settlement;
  fromPlayer: { name: string; avatar?: string };
  toPlayer: { name: string; avatar?: string };
  onMarkSettled: () => void;
}

const SettlementCard: React.FC<SettlementCardProps> = ({
  settlement,
  fromPlayer,
  toPlayer,
  onMarkSettled,
}) => {
  return (
    <View style={[
      styles.container, 
      settlement.settled ? styles.settledContainer : null
    ]}>
      <View style={styles.playerSection}>
        <Avatar name={fromPlayer.name} imageUrl={fromPlayer.avatar} size={40} />
        <Text style={styles.playerName}>{fromPlayer.name}</Text>
      </View>
      
      <View style={styles.arrowSection}>
        <View style={styles.amountContainer}>
          <Text style={styles.amountText}>${settlement.amount.toFixed(2)}</Text>
        </View>
        <ArrowRight size={20} color={colors.dark.primary} />
      </View>
      
      <View style={styles.playerSection}>
        <Avatar name={toPlayer.name} imageUrl={toPlayer.avatar} size={40} />
        <Text style={styles.playerName}>{toPlayer.name}</Text>
      </View>
      
      {!settlement.settled ? (
        <TouchableOpacity 
          style={styles.settleButton}
          onPress={onMarkSettled}
        >
          <Text style={styles.settleButtonText}>Mark Settled</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.settledBadge}>
          <Check size={16} color={colors.dark.success} />
          <Text style={styles.settledText}>Settled</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
  },
  settledContainer: {
    opacity: 0.7,
    borderColor: colors.dark.success,
    borderWidth: 1,
  },
  playerSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
  playerName: {
    marginLeft: 12,
    fontSize: 16,
    color: colors.dark.text,
    fontWeight: '500',
  },
  arrowSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 8,
  },
  amountContainer: {
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 12,
    marginRight: 8,
  },
  amountText: {
    color: colors.dark.primary,
    fontWeight: 'bold',
    fontSize: 16,
  },
  settleButton: {
    backgroundColor: colors.dark.primary,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    alignSelf: 'center',
    marginTop: 12,
  },
  settleButtonText: {
    color: colors.dark.background,
    fontWeight: '600',
    fontSize: 14,
  },
  settledBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 12,
    alignSelf: 'center',
    marginTop: 12,
  },
  settledText: {
    color: colors.dark.success,
    fontWeight: '600',
    fontSize: 14,
    marginLeft: 4,
  },
});

export default SettlementCard;