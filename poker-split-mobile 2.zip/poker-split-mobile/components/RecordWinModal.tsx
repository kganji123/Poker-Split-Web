import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Modal, 
  TouchableOpacity, 
  ScrollView,
  FlatList
} from 'react-native';
import { X, Award } from 'lucide-react-native';
import colors from '@/constants/colors';
import Button from './Button';
import Avatar from './Avatar';

interface RecordWinModalProps {
  visible: boolean;
  onClose: () => void;
  players: Array<{ userId: string; name: string; avatar?: string }>;
  onRecordWin: (playerId: string, handType: string) => void;
}

const POKER_HANDS = [
  'Royal Flush',
  'Straight Flush',
  'Four of a Kind',
  'Full House',
  'Flush',
  'Straight',
  'Three of a Kind',
  'Two Pair',
  'Pair',
  'High Card',
];

const RecordWinModal: React.FC<RecordWinModalProps> = ({
  visible,
  onClose,
  players,
  onRecordWin,
}) => {
  const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null);
  const [selectedHand, setSelectedHand] = useState<string | null>(null);

  const handleSubmit = () => {
    if (selectedPlayer && selectedHand) {
      onRecordWin(selectedPlayer, selectedHand);
      resetForm();
    }
  };

  const resetForm = () => {
    setSelectedPlayer(null);
    setSelectedHand(null);
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.container}>
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.title}>Record Win</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color={colors.dark.text} />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content}>
            <Text style={styles.sectionTitle}>Select Winner</Text>
            <View style={styles.playersList}>
              {players.map(player => (
                <TouchableOpacity
                  key={player.userId}
                  style={[
                    styles.playerItem,
                    selectedPlayer === player.userId && styles.selectedPlayerItem
                  ]}
                  onPress={() => setSelectedPlayer(player.userId)}
                >
                  <Avatar name={player.name} imageUrl={player.avatar} size={40} />
                  <Text style={[
                    styles.playerName,
                    selectedPlayer === player.userId && styles.selectedPlayerName
                  ]}>
                    {player.name}
                  </Text>
                  {selectedPlayer === player.userId && (
                    <Award size={20} color={colors.dark.gold} />
                  )}
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.sectionTitle}>Select Winning Hand</Text>
            <View style={styles.handsList}>
              {POKER_HANDS.map(hand => (
                <TouchableOpacity
                  key={hand}
                  style={[
                    styles.handItem,
                    selectedHand === hand && styles.selectedHandItem
                  ]}
                  onPress={() => setSelectedHand(hand)}
                >
                  <Text style={[
                    styles.handName,
                    selectedHand === hand && styles.selectedHandName
                  ]}>
                    {hand}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.buttonContainer}>
              <Button
                title="Record Win"
                onPress={handleSubmit}
                disabled={!selectedPlayer || !selectedHand}
                style={styles.submitButton}
              />
              <Button
                title="Cancel"
                onPress={onClose}
                variant="ghost"
              />
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.dark.background,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '80%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  closeButton: {
    padding: 4,
  },
  content: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
    marginTop: 8,
  },
  playersList: {
    marginBottom: 24,
  },
  playerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: colors.dark.card,
  },
  selectedPlayerItem: {
    backgroundColor: colors.dark.primary,
  },
  playerName: {
    fontSize: 16,
    color: colors.dark.text,
    marginLeft: 12,
    flex: 1,
  },
  selectedPlayerName: {
    color: colors.dark.background,
    fontWeight: 'bold',
  },
  handsList: {
    marginBottom: 24,
  },
  handItem: {
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: colors.dark.card,
  },
  selectedHandItem: {
    backgroundColor: colors.dark.primary,
  },
  handName: {
    fontSize: 16,
    color: colors.dark.text,
  },
  selectedHandName: {
    color: colors.dark.background,
    fontWeight: 'bold',
  },
  buttonContainer: {
    marginTop: 16,
    marginBottom: 32,
  },
  submitButton: {
    marginBottom: 12,
  },
});

export default RecordWinModal;