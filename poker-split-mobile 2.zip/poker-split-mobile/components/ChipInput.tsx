import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity,
  StyleProp,
  ViewStyle
} from 'react-native';
import { Minus, Plus } from 'lucide-react-native';
import colors from '@/constants/colors';
import Input from './Input';

interface ChipInputProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  step?: number;
  min?: number;
  max?: number;
  style?: StyleProp<ViewStyle>;
  chipColor?: string;
}

const ChipInput: React.FC<ChipInputProps> = ({
  label,
  value,
  onChange,
  step = 100,
  min = 0,
  max = 100000,
  style,
  chipColor,
}) => {
  const [inputValue, setInputValue] = useState(value.toString());

  // Determine chip color based on value
  const getChipColor = () => {
    if (chipColor) return chipColor;
    
    // Default poker chip colors based on value
    if (value >= 5000) return colors.dark.chipBlack;
    if (value >= 1000) return colors.dark.chipBlue;
    if (value >= 500) return colors.dark.chipRed;
    if (value >= 100) return colors.dark.chipGold;
    return colors.dark.chip;
  };

  useEffect(() => {
    setInputValue(value.toString());
  }, [value]);

  const handleInputChange = (text: string) => {
    // Allow only numbers
    const numericValue = text.replace(/[^0-9]/g, '');
    setInputValue(numericValue);
    
    // Update parent component if valid number
    if (numericValue) {
      const newValue = parseInt(numericValue, 10);
      if (newValue >= min && newValue <= max) {
        onChange(newValue);
      }
    } else {
      onChange(0);
    }
  };

  const handleIncrement = () => {
    const newValue = Math.min(value + step, max);
    onChange(newValue);
    setInputValue(newValue.toString());
  };

  const handleDecrement = () => {
    const newValue = Math.max(value - step, min);
    onChange(newValue);
    setInputValue(newValue.toString());
  };

  return (
    <View style={[styles.container, style]}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.inputContainer}>
        <View style={styles.chipIconContainer}>
          <View style={[styles.chipIcon, { backgroundColor: getChipColor() }]} />
        </View>
        <TouchableOpacity 
          style={styles.button} 
          onPress={handleDecrement}
          disabled={value <= min}
        >
          <Minus size={20} color={value <= min ? colors.dark.inactive : colors.dark.text} />
        </TouchableOpacity>
        <Input
          value={inputValue}
          onChangeText={handleInputChange}
          keyboardType="numeric"
          style={styles.input}
          inputStyle={styles.inputText}
        />
        <TouchableOpacity 
          style={styles.button} 
          onPress={handleIncrement}
          disabled={value >= max}
        >
          <Plus size={20} color={value >= max ? colors.dark.inactive : colors.dark.text} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    color: colors.dark.text,
    fontWeight: '500',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    backgroundColor: colors.dark.cardAlt,
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  chipIconContainer: {
    paddingHorizontal: 12,
  },
  chipIcon: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.dark.text,
  },
  button: {
    padding: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    marginBottom: 0,
  },
  inputText: {
    textAlign: 'center',
    fontWeight: 'bold',
  },
});

export default ChipInput;