import React from 'react';
import { 
  TouchableOpacity, 
  Text, 
  StyleSheet, 
  ActivityIndicator,
  ViewStyle,
  TextStyle,
  StyleProp
} from 'react-native';
import colors from '@/constants/colors';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
type ButtonSize = 'small' | 'medium' | 'large';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
}

const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  loading = false,
  style,
  textStyle,
  icon,
  iconPosition = 'left',
}) => {
  const getButtonStyle = () => {
    const baseStyle: ViewStyle = {
      ...styles.button,
      ...styles[size],
    };

    if (disabled) {
      return {
        ...baseStyle,
        ...styles[`${variant}Disabled`],
      };
    }

    return {
      ...baseStyle,
      ...styles[variant],
    };
  };

  const getTextStyle = () => {
    const baseStyle: TextStyle = {
      ...styles.text,
      ...styles[`${size}Text`],
    };

    if (disabled) {
      return {
        ...baseStyle,
        ...styles[`${variant}DisabledText`],
      };
    }

    return {
      ...baseStyle,
      ...styles[`${variant}Text`],
    };
  };

  return (
    <TouchableOpacity
      style={[getButtonStyle(), style]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading ? (
        <ActivityIndicator 
          color={variant === 'outline' || variant === 'ghost' ? colors.dark.primary : colors.dark.text} 
          size="small" 
        />
      ) : (
        <>
          {icon && iconPosition === 'left' && icon}
          <Text style={[getTextStyle(), textStyle]}>{title}</Text>
          {icon && iconPosition === 'right' && icon}
        </>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  text: {
    fontWeight: '600',
  },
  small: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  medium: {
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  large: {
    paddingVertical: 16,
    paddingHorizontal: 24,
  },
  smallText: {
    fontSize: 14,
  },
  mediumText: {
    fontSize: 16,
  },
  largeText: {
    fontSize: 18,
  },
  primary: {
    backgroundColor: colors.dark.primary,
  },
  primaryText: {
    color: colors.dark.background,
  },
  primaryDisabled: {
    backgroundColor: colors.dark.inactive,
  },
  primaryDisabledText: {
    color: colors.dark.textSecondary,
  },
  secondary: {
    backgroundColor: colors.dark.secondary,
  },
  secondaryText: {
    color: colors.dark.text,
  },
  secondaryDisabled: {
    backgroundColor: colors.dark.inactive,
  },
  secondaryDisabledText: {
    color: colors.dark.textSecondary,
  },
  outline: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: colors.dark.primary,
  },
  outlineText: {
    color: colors.dark.primary,
  },
  outlineDisabled: {
    borderColor: colors.dark.inactive,
  },
  outlineDisabledText: {
    color: colors.dark.inactive,
  },
  ghost: {
    backgroundColor: 'transparent',
  },
  ghostText: {
    color: colors.dark.primary,
  },
  ghostDisabled: {
    backgroundColor: 'transparent',
  },
  ghostDisabledText: {
    color: colors.dark.inactive,
  },
  danger: {
    backgroundColor: colors.dark.error,
  },
  dangerText: {
    color: colors.dark.text,
  },
  dangerDisabled: {
    backgroundColor: colors.dark.inactive,
  },
  dangerDisabledText: {
    color: colors.dark.textSecondary,
  },
});

export default Button;