import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, Image } from 'react-native';
import { router } from 'expo-router';
import { Plus, Clock, DollarSign, Users as UsersIcon, HelpCircle } from 'lucide-react-native';
import colors from '@/constants/colors';
import useStore from '@/store/useStore';
import Card from '@/components/Card';
import Button from '@/components/Button';
import EmptyState from '@/components/EmptyState';

export default function HomeScreen() {
  const { user, games, groups, activeGame, setActiveGame } = useStore();
  const [refreshing, setRefreshing] = useState(false);

  const recentGames = [...games]
    .filter(game => !game.isActive)
    .sort((a, b) => b.endedAt! - a.endedAt!)
    .slice(0, 3);

  const activeGames = games.filter(game => game.isActive);
  
  const onRefresh = () => {
    setRefreshing(true);
    // In a real app, you would fetch data from an API here
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  // Use a state to track if we should redirect
  const [shouldRedirect, setShouldRedirect] = useState(false);

  useEffect(() => {
    // Set a flag instead of redirecting immediately
    if (!user) {
      setShouldRedirect(true);
    }
  }, [user]);

  // Only redirect after component is mounted
  useEffect(() => {
    if (shouldRedirect) {
      // Use a small timeout to ensure layout is mounted
      const timer = setTimeout(() => {
        router.replace('/(auth)/login');
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [shouldRedirect]);

  if (!user) return null;

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      refreshControl={
        <RefreshControl 
          refreshing={refreshing} 
          onRefresh={onRefresh}
          tintColor={colors.dark.primary}
          colors={[colors.dark.primary]}
        />
      }
    >
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Hello, {user.name}</Text>
          <Text style={styles.subGreeting}>Ready to split some poker winnings?</Text>
        </View>
        <TouchableOpacity 
          style={styles.pokerCardContainer}
          onPress={() => router.push('/poker-hands')}
        >
          <View style={styles.pokerCard}>
            <View style={styles.cardCorner}>
              <Text style={styles.cardRank}>A</Text>
              <Text style={styles.cardSuit}>♠</Text>
            </View>
            <Text style={styles.cardSuitCenter}>♠</Text>
            <View style={[styles.cardCorner, styles.cardCornerBottom]}>
              <Text style={styles.cardRank}>A</Text>
              <Text style={styles.cardSuit}>♠</Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>

      {/* Active Games Section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Active Games</Text>
          <TouchableOpacity 
            style={styles.newButton}
            onPress={() => router.push('/game/create')}
          >
            <Plus size={16} color={colors.dark.primary} />
            <Text style={styles.newButtonText}>New Game</Text>
          </TouchableOpacity>
        </View>

        {activeGames.length > 0 ? (
          activeGames.map(game => {
            const group = groups.find(g => g.id === game.groupId);
            return (
              <Card key={game.id} style={styles.gameCard}>
                <TouchableOpacity 
                  style={styles.gameCardContent}
                  onPress={() => {
                    setActiveGame(game.id);
                    router.push(`/game/${game.id}`);
                  }}
                >
                  <View style={styles.gameInfo}>
                    <Text style={styles.gameName}>{game.name}</Text>
                    <Text style={styles.gameGroup}>{group?.name || 'Unknown Group'}</Text>
                    
                    <View style={styles.gameStats}>
                      <View style={styles.statItem}>
                        <Clock size={16} color={colors.dark.textSecondary} />
                        <Text style={styles.statText}>
                          {new Date(game.date).toLocaleDateString()}
                        </Text>
                      </View>
                      
                      <View style={styles.statItem}>
                        <UsersIcon size={16} color={colors.dark.textSecondary} />
                        <Text style={styles.statText}>
                          {game.players.length} players
                        </Text>
                      </View>
                      
                      <View style={styles.statItem}>
                        <DollarSign size={16} color={colors.dark.textSecondary} />
                        <Text style={styles.statText}>
                          {group ? `${group.chipValue}/1000 chips` : 'Unknown value'}
                        </Text>
                      </View>
                    </View>
                  </View>
                  
                  <View style={styles.continueButton}>
                    <Button 
                      title="Continue" 
                      onPress={() => {
                        setActiveGame(game.id);
                        router.push(`/game/${game.id}`);
                      }}
                      size="small"
                    />
                  </View>
                </TouchableOpacity>
              </Card>
            );
          })
        ) : (
          <EmptyState
            title="No Active Games"
            message="Start a new poker game to track chips and calculate settlements."
            actionLabel="Start Game"
            onAction={() => router.push('/game/create')}
          />
        )}
      </View>

      {/* Recent Games Section */}
      {recentGames.length > 0 && (
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Games</Text>
            <TouchableOpacity onPress={() => router.push('/stats')}>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>

          {recentGames.map(game => {
            const group = groups.find(g => g.id === game.groupId);
            return (
              <Card key={game.id} style={styles.recentGameCard}>
                <TouchableOpacity 
                  style={styles.gameCardContent}
                  onPress={() => router.push(`/game/${game.id}`)}
                >
                  <View style={styles.gameInfo}>
                    <Text style={styles.gameName}>{game.name}</Text>
                    <Text style={styles.gameGroup}>{group?.name || 'Unknown Group'}</Text>
                    
                    <View style={styles.gameStats}>
                      <View style={styles.statItem}>
                        <Clock size={16} color={colors.dark.textSecondary} />
                        <Text style={styles.statText}>
                          {new Date(game.date).toLocaleDateString()}
                        </Text>
                      </View>
                      
                      <View style={styles.statItem}>
                        <UsersIcon size={16} color={colors.dark.textSecondary} />
                        <Text style={styles.statText}>
                          {game.players.length} players
                        </Text>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              </Card>
            );
          })}
        </View>
      )}

      {/* Quick Actions */}
      <View style={styles.quickActions}>
        <Button 
          title="Create New Group" 
          onPress={() => router.push('/group/create')}
          variant="outline"
          style={styles.quickActionButton}
        />
        <Button 
          title="View All Groups" 
          onPress={() => router.push('/groups')}
          variant="outline"
          style={styles.quickActionButton}
        />
      </View>

      {/* Poker Hands Reference Button */}
      <TouchableOpacity 
        style={styles.pokerHandsButton}
        onPress={() => router.push('/poker-hands')}
      >
        <HelpCircle size={20} color={colors.dark.text} />
        <Text style={styles.pokerHandsButtonText}>Poker Hands Reference</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  greeting: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  subGreeting: {
    fontSize: 16,
    color: colors.dark.textSecondary,
    marginTop: 4,
  },
  pokerCardContainer: {
    marginTop: 4,
  },
  pokerCard: {
    width: 50,
    height: 70,
    backgroundColor: '#FFFFFF',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  cardCorner: {
    position: 'absolute',
    top: 5,
    left: 5,
    alignItems: 'center',
  },
  cardCornerBottom: {
    top: undefined,
    left: undefined,
    bottom: 5,
    right: 5,
    transform: [{ rotate: '180deg' }],
  },
  cardRank: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000000',
  },
  cardSuit: {
    fontSize: 12,
    color: '#D32F2F',
    lineHeight: 12,
  },
  cardSuitCenter: {
    fontSize: 30,
    color: '#D32F2F',
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  newButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  newButtonText: {
    color: colors.dark.primary,
    marginLeft: 4,
    fontWeight: '500',
  },
  viewAllText: {
    color: colors.dark.primary,
    fontWeight: '500',
  },
  gameCard: {
    marginBottom: 12,
  },
  recentGameCard: {
    marginBottom: 8,
    opacity: 0.9,
  },
  gameCardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  gameInfo: {
    flex: 1,
  },
  gameName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  gameGroup: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginBottom: 8,
  },
  gameStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginLeft: 4,
  },
  continueButton: {
    marginLeft: 12,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
    marginBottom: 24,
  },
  quickActionButton: {
    flex: 1,
    marginHorizontal: 4,
  },
  pokerHandsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 12,
    padding: 12,
    marginBottom: 24,
  },
  pokerHandsButtonText: {
    color: colors.dark.text,
    marginLeft: 8,
    fontSize: 16,
    fontWeight: '500',
  },
});