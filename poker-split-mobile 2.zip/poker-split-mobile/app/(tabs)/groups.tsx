import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { router } from 'expo-router';
import { Plus, Users, DollarSign, Calendar } from 'lucide-react-native';
import colors from '@/constants/colors';
import useStore from '@/store/useStore';
import Card from '@/components/Card';
import EmptyState from '@/components/EmptyState';

export default function GroupsScreen() {
  const { groups, games, user } = useStore();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = () => {
    setRefreshing(true);
    // In a real app, you would fetch data from an API here
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const getGroupStats = (groupId: string) => {
    const groupGames = games.filter(game => game.groupId === groupId);
    return {
      totalGames: groupGames.length,
      activeGames: groupGames.filter(game => game.isActive).length,
      lastPlayed: groupGames.length > 0 
        ? Math.max(...groupGames.map(game => game.date))
        : null,
    };
  };

  const renderGroupCard = ({ item: group }) => {
    const stats = getGroupStats(group.id);
    const isAdmin = group.adminId === user?.id;

    return (
      <Card style={styles.groupCard}>
        <TouchableOpacity 
          style={styles.groupCardContent}
          onPress={() => router.push(`/group/${group.id}`)}
        >
          <View style={styles.groupInfo}>
            <Text style={styles.groupName}>{group.name}</Text>
            
            {isAdmin && (
              <View style={styles.adminBadge}>
                <Text style={styles.adminBadgeText}>Admin</Text>
              </View>
            )}
            
            <View style={styles.groupStats}>
              <View style={styles.statItem}>
                <Users size={16} color={colors.dark.textSecondary} />
                <Text style={styles.statText}>
                  {group.members.length} members
                </Text>
              </View>
              
              <View style={styles.statItem}>
                <DollarSign size={16} color={colors.dark.textSecondary} />
                <Text style={styles.statText}>
                  ${group.chipValue}/1000 chips
                </Text>
              </View>
              
              <View style={styles.statItem}>
                <Calendar size={16} color={colors.dark.textSecondary} />
                <Text style={styles.statText}>
                  {stats.totalGames} games
                </Text>
              </View>
            </View>
          </View>
          
          {stats.activeGames > 0 && (
            <View style={styles.activeBadge}>
              <Text style={styles.activeBadgeText}>{stats.activeGames} Active</Text>
            </View>
          )}
        </TouchableOpacity>
      </Card>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Your Poker Groups</Text>
        <TouchableOpacity 
          style={styles.createButton}
          onPress={() => router.push('/group/create')}
        >
          <Plus size={20} color={colors.dark.text} />
        </TouchableOpacity>
      </View>

      {groups.length > 0 ? (
        <FlatList
          data={groups}
          keyExtractor={(item) => item.id}
          renderItem={renderGroupCard}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl 
              refreshing={refreshing} 
              onRefresh={onRefresh}
              tintColor={colors.dark.primary}
              colors={[colors.dark.primary]}
            />
          }
        />
      ) : (
        <EmptyState
          title="No Groups Yet"
          message="Create a poker group to start tracking games and settlements."
          actionLabel="Create Group"
          onAction={() => router.push('/group/create')}
          icon={<Users size={48} color={colors.dark.textSecondary} />}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingBottom: 8,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  createButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    padding: 16,
    paddingTop: 8,
  },
  groupCard: {
    marginBottom: 12,
  },
  groupCardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  groupInfo: {
    flex: 1,
  },
  groupName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  adminBadge: {
    backgroundColor: colors.dark.primary,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: 'flex-start',
    marginBottom: 8,
  },
  adminBadgeText: {
    color: colors.dark.background,
    fontSize: 12,
    fontWeight: '600',
  },
  groupStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginLeft: 4,
  },
  activeBadge: {
    backgroundColor: colors.dark.success,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  activeBadgeText: {
    color: colors.dark.background,
    fontSize: 12,
    fontWeight: '600',
  },
});