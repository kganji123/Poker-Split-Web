import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, Alert, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { 
  User, 
  LogOut, 
  Bell, 
  Moon, 
  HelpCircle, 
  Shield, 
  Trash2,
  ChevronRight
} from 'lucide-react-native';
import colors from '@/constants/colors';
import useStore from '@/store/useStore';
import Card from '@/components/Card';
import Avatar from '@/components/Avatar';
import Button from '@/components/Button';

export default function SettingsScreen() {
  const { user, setUser } = useStore();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  
  if (!user) return null;

  const handleLogout = () => {
    Alert.alert(
      "Logout",
      "Are you sure you want to logout?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Logout", 
          onPress: () => {
            setUser(null);
            router.replace('/(auth)/login');
          },
          style: "destructive"
        }
      ]
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      "Delete Account",
      "Are you sure you want to delete your account? This action cannot be undone.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Delete", 
          onPress: () => {
            // In a real app, you would call an API to delete the account
            setUser(null);
            router.replace('/(auth)/login');
          },
          style: "destructive"
        }
      ]
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      {/* Profile Section */}
      <Card style={styles.profileCard}>
        <View style={styles.profileHeader}>
          <Avatar name={user.name} imageUrl={user.avatar} size={80} />
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{user.name}</Text>
            <Text style={styles.profileEmail}>{user.email || "No email provided"}</Text>
          </View>
        </View>
        
        <Button
          title="Edit Profile"
          onPress={() => {
            // In a real app, navigate to profile edit screen
            Alert.alert("Edit Profile", "This feature would allow editing your profile.");
          }}
          variant="outline"
          style={styles.editProfileButton}
        />
      </Card>
      
      {/* Preferences Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preferences</Text>
        
        <Card style={styles.settingsCard}>
          <View style={styles.settingItem}>
            <View style={styles.settingIconContainer}>
              <Bell size={20} color={colors.dark.primary} />
            </View>
            <Text style={styles.settingText}>Notifications</Text>
            <Switch
              value={notifications}
              onValueChange={setNotifications}
              trackColor={{ false: colors.dark.inactive, true: colors.dark.primary }}
              thumbColor={colors.dark.text}
            />
          </View>
          
          <View style={styles.divider} />
          
          <View style={styles.settingItem}>
            <View style={styles.settingIconContainer}>
              <Moon size={20} color={colors.dark.primary} />
            </View>
            <Text style={styles.settingText}>Dark Mode</Text>
            <Switch
              value={darkMode}
              onValueChange={setDarkMode}
              trackColor={{ false: colors.dark.inactive, true: colors.dark.primary }}
              thumbColor={colors.dark.text}
            />
          </View>
        </Card>
      </View>
      
      {/* Support Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Support</Text>
        
        <Card style={styles.settingsCard}>
          <TouchableOpacity 
            style={styles.settingItem}
            onPress={() => {
              Alert.alert("Help & Support", "This would open the help and support screen.");
            }}
          >
            <View style={styles.settingIconContainer}>
              <HelpCircle size={20} color={colors.dark.primary} />
            </View>
            <Text style={styles.settingText}>Help & Support</Text>
            <ChevronRight size={20} color={colors.dark.textSecondary} />
          </TouchableOpacity>
          
          <View style={styles.divider} />
          
          <TouchableOpacity 
            style={styles.settingItem}
            onPress={() => {
              Alert.alert("Privacy Policy", "This would open the privacy policy screen.");
            }}
          >
            <View style={styles.settingIconContainer}>
              <Shield size={20} color={colors.dark.primary} />
            </View>
            <Text style={styles.settingText}>Privacy Policy</Text>
            <ChevronRight size={20} color={colors.dark.textSecondary} />
          </TouchableOpacity>
        </Card>
      </View>
      
      {/* Account Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account</Text>
        
        <Card style={styles.settingsCard}>
          <TouchableOpacity 
            style={styles.settingItem}
            onPress={handleLogout}
          >
            <View style={styles.settingIconContainer}>
              <LogOut size={20} color={colors.dark.error} />
            </View>
            <Text style={[styles.settingText, { color: colors.dark.error }]}>Logout</Text>
            <ChevronRight size={20} color={colors.dark.textSecondary} />
          </TouchableOpacity>
          
          <View style={styles.divider} />
          
          <TouchableOpacity 
            style={styles.settingItem}
            onPress={handleDeleteAccount}
          >
            <View style={styles.settingIconContainer}>
              <Trash2 size={20} color={colors.dark.error} />
            </View>
            <Text style={[styles.settingText, { color: colors.dark.error }]}>Delete Account</Text>
            <ChevronRight size={20} color={colors.dark.textSecondary} />
          </TouchableOpacity>
        </Card>
      </View>
      
      <Text style={styles.versionText}>Version 1.0.0</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
  },
  profileCard: {
    marginBottom: 24,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  profileInfo: {
    marginLeft: 16,
  },
  profileName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  editProfileButton: {
    marginTop: 8,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
    marginLeft: 4,
  },
  settingsCard: {
    padding: 0,
    overflow: 'hidden',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  settingIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.dark.cardAlt,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  settingText: {
    flex: 1,
    fontSize: 16,
    color: colors.dark.text,
  },
  divider: {
    height: 1,
    backgroundColor: colors.dark.border,
    marginHorizontal: 16,
  },
  versionText: {
    textAlign: 'center',
    color: colors.dark.textSecondary,
    marginBottom: 24,
    fontSize: 14,
  },
});