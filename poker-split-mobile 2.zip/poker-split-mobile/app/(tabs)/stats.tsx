import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { BarChart3, TrendingUp, TrendingDown, DollarSign, Calendar, Trophy } from 'lucide-react-native';
import colors from '@/constants/colors';
import useStore from '@/store/useStore';
import Card from '@/components/Card';
import LeaderboardCard from '@/components/LeaderboardCard';

export default function StatsScreen() {
  const { user, games, groups, getUserStats } = useStore();
  const [selectedFilter, setSelectedFilter] = useState('all'); // 'all', 'month', 'year'
  const [activeTab, setActiveTab] = useState('personal'); // 'personal', 'leaderboard'
  
  if (!user) return null;
  
  const userStats = getUserStats(user.id);
  
  // Get completed games
  const completedGames = games.filter(game => !game.isActive);
  
  // Filter games based on selected time period
  const filteredGames = completedGames.filter(game => {
    if (selectedFilter === 'all') return true;
    
    const gameDate = new Date(game.date);
    const now = new Date();
    
    if (selectedFilter === 'month') {
      return (
        gameDate.getMonth() === now.getMonth() &&
        gameDate.getFullYear() === now.getFullYear()
      );
    }
    
    if (selectedFilter === 'year') {
      return gameDate.getFullYear() === now.getFullYear();
    }
    
    return true;
  });
  
  // Calculate win/loss streak
  const calculateStreak = () => {
    if (filteredGames.length === 0) return { type: 'none', count: 0 };
    
    const userResults = filteredGames
      .sort((a, b) => b.date - a.date) // Sort by date, newest first
      .map(game => {
        const player = game.players.find(p => p.userId === user.id);
        return player?.netResult || 0;
      });
    
    let streakCount = 1;
    const currentResult = userResults[0];
    const streakType = currentResult > 0 ? 'win' : currentResult < 0 ? 'loss' : 'draw';
    
    if (streakType === 'draw') return { type: 'draw', count: 1 };
    
    for (let i = 1; i < userResults.length; i++) {
      const result = userResults[i];
      if ((streakType === 'win' && result > 0) || 
          (streakType === 'loss' && result < 0)) {
        streakCount++;
      } else {
        break;
      }
    }
    
    return { type: streakType, count: streakCount };
  };
  
  const streak = calculateStreak();
  
  // Calculate biggest win and loss
  const biggestWin = Math.max(
    0,
    ...filteredGames.map(game => {
      const player = game.players.find(p => p.userId === user.id);
      return player?.netResult && player.netResult > 0 ? player.netResult : 0;
    })
  );
  
  const biggestLoss = Math.max(
    0,
    ...filteredGames.map(game => {
      const player = game.players.find(p => p.userId === user.id);
      return player?.netResult && player.netResult < 0 ? Math.abs(player.netResult) : 0;
    })
  );
  
  // Calculate total profit/loss
  const totalProfitLoss = filteredGames.reduce((sum, game) => {
    const player = game.players.find(p => p.userId === user.id);
    return sum + (player?.netResult || 0);
  }, 0);
  
  // Calculate win rate
  const gamesWithResults = filteredGames.filter(game => {
    const player = game.players.find(p => p.userId === user.id);
    return player && player.netResult !== undefined;
  });
  
  const wins = gamesWithResults.filter(game => {
    const player = game.players.find(p => p.userId === user.id);
    return player && player.netResult! > 0;
  });
  
  const winRate = gamesWithResults.length > 0 
    ? (wins.length / gamesWithResults.length) * 100 
    : 0;

  // Generate leaderboard data
  const generateLeaderboard = () => {
    // Create a map to track player stats across all games
    const playerStats = new Map();
    
    // Process all completed games
    completedGames.forEach(game => {
      game.players.forEach(player => {
        if (player.netResult === undefined) return;
        
        // Get or initialize player stats
        const stats = playerStats.get(player.userId) || {
          userId: player.userId,
          name: player.name,
          avatar: player.avatar,
          totalWinnings: 0,
          gamesPlayed: 0,
          wins: 0,
        };
        
        // Update stats
        stats.totalWinnings += player.netResult;
        stats.gamesPlayed += 1;
        if (player.netResult > 0) stats.wins += 1;
        
        // Save updated stats
        playerStats.set(player.userId, stats);
      });
    });
    
    // Convert map to array and calculate win rate
    const leaderboardData = Array.from(playerStats.values()).map(stats => ({
      ...stats,
      winRate: stats.gamesPlayed > 0 ? stats.wins / stats.gamesPlayed : 0,
    }));
    
    // Sort by total winnings (descending)
    return leaderboardData.sort((a, b) => b.totalWinnings - a.totalWinnings);
  };
  
  const leaderboard = generateLeaderboard();

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <Text style={styles.title}>Stats</Text>
        
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[
              styles.tabButton,
              activeTab === 'personal' && styles.tabButtonActive,
            ]}
            onPress={() => setActiveTab('personal')}
          >
            <Text
              style={[
                styles.tabButtonText,
                activeTab === 'personal' && styles.tabButtonTextActive,
              ]}
            >
              Personal
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.tabButton,
              activeTab === 'leaderboard' && styles.tabButtonActive,
            ]}
            onPress={() => setActiveTab('leaderboard')}
          >
            <Text
              style={[
                styles.tabButtonText,
                activeTab === 'leaderboard' && styles.tabButtonTextActive,
              ]}
            >
              Leaderboard
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {activeTab === 'personal' ? (
        // Personal Stats View
        <>
          <View style={styles.filterContainer}>
            <TouchableOpacity
              style={[
                styles.filterButton,
                selectedFilter === 'all' && styles.filterButtonActive,
              ]}
              onPress={() => setSelectedFilter('all')}
            >
              <Text
                style={[
                  styles.filterButtonText,
                  selectedFilter === 'all' && styles.filterButtonTextActive,
                ]}
              >
                All Time
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.filterButton,
                selectedFilter === 'year' && styles.filterButtonActive,
              ]}
              onPress={() => setSelectedFilter('year')}
            >
              <Text
                style={[
                  styles.filterButtonText,
                  selectedFilter === 'year' && styles.filterButtonTextActive,
                ]}
              >
                This Year
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.filterButton,
                selectedFilter === 'month' && styles.filterButtonActive,
              ]}
              onPress={() => setSelectedFilter('month')}
            >
              <Text
                style={[
                  styles.filterButtonText,
                  selectedFilter === 'month' && styles.filterButtonTextActive,
                ]}
              >
                This Month
              </Text>
            </TouchableOpacity>
          </View>
          
          {/* Summary Cards */}
          <View style={styles.summaryContainer}>
            <Card style={styles.summaryCard}>
              <View style={styles.summaryIconContainer}>
                <Calendar size={24} color={colors.dark.primary} />
              </View>
              <Text style={styles.summaryValue}>{gamesWithResults.length}</Text>
              <Text style={styles.summaryLabel}>Games Played</Text>
            </Card>
            
            <Card style={styles.summaryCard}>
              <View style={styles.summaryIconContainer}>
                <BarChart3 size={24} color={colors.dark.primary} />
              </View>
              <Text style={styles.summaryValue}>{winRate.toFixed(0)}%</Text>
              <Text style={styles.summaryLabel}>Win Rate</Text>
            </Card>
          </View>
          
          {/* Profit/Loss Card */}
          <Card style={styles.profitLossCard}>
            <View style={styles.profitLossHeader}>
              <DollarSign size={24} color={colors.dark.primary} />
              <Text style={styles.profitLossTitle}>Total Profit/Loss</Text>
            </View>
            
            <Text style={[
              styles.profitLossValue,
              totalProfitLoss > 0 ? styles.profitValue : totalProfitLoss < 0 ? styles.lossValue : null,
            ]}>
              {totalProfitLoss > 0 ? '+' : ''}{totalProfitLoss.toFixed(2)}
            </Text>
          </Card>
          
          {/* Streak Card */}
          <Card style={styles.streakCard}>
            <View style={styles.streakHeader}>
              {streak.type === 'win' ? (
                <TrendingUp size={24} color={colors.dark.success} />
              ) : streak.type === 'loss' ? (
                <TrendingDown size={24} color={colors.dark.secondary} />
              ) : (
                <BarChart3 size={24} color={colors.dark.textSecondary} />
              )}
              
              <Text style={styles.streakTitle}>
                Current {streak.type === 'win' ? 'Win' : streak.type === 'loss' ? 'Loss' : 'No'} Streak
              </Text>
            </View>
            
            {streak.type !== 'none' && (
              <Text style={[
                styles.streakValue,
                streak.type === 'win' ? styles.winStreakValue : 
                streak.type === 'loss' ? styles.lossStreakValue : null,
              ]}>
                {streak.count} {streak.count === 1 ? 'game' : 'games'}
              </Text>
            )}
          </Card>
          
          {/* Best/Worst Performance */}
          <View style={styles.performanceContainer}>
            <Card style={[styles.performanceCard, styles.winCard]}>
              <Text style={styles.performanceTitle}>Biggest Win</Text>
              <Text style={styles.performanceValue}>${biggestWin.toFixed(2)}</Text>
            </Card>
            
            <Card style={[styles.performanceCard, styles.lossCard]}>
              <Text style={styles.performanceTitle}>Biggest Loss</Text>
              <Text style={styles.performanceValue}>${biggestLoss.toFixed(2)}</Text>
            </Card>
          </View>
          
          {/* Recent Games */}
          <View style={styles.recentGamesSection}>
            <Text style={styles.sectionTitle}>Recent Games</Text>
            
            {filteredGames.slice(0, 5).map(game => {
              const player = game.players.find(p => p.userId === user.id);
              const group = groups.find(g => g.id === game.groupId);
              const result = player?.netResult || 0;
              
              return (
                <Card key={game.id} style={styles.recentGameCard}>
                  <View style={styles.recentGameHeader}>
                    <Text style={styles.recentGameName}>{game.name}</Text>
                    <Text style={styles.recentGameDate}>
                      {new Date(game.date).toLocaleDateString()}
                    </Text>
                  </View>
                  
                  <View style={styles.recentGameDetails}>
                    <Text style={styles.recentGameGroup}>{group?.name || 'Unknown Group'}</Text>
                    
                    <Text style={[
                      styles.recentGameResult,
                      result > 0 ? styles.winResult : result < 0 ? styles.lossResult : null,
                    ]}>
                      {result > 0 ? '+' : ''}{result.toFixed(2)}
                    </Text>
                  </View>
                </Card>
              );
            })}
          </View>
        </>
      ) : (
        // Leaderboard View
        <View style={styles.leaderboardContainer}>
          <View style={styles.leaderboardHeader}>
            <Trophy size={24} color={colors.dark.gold} />
            <Text style={styles.leaderboardTitle}>Global Leaderboard</Text>
          </View>
          
          {leaderboard.length > 0 ? (
            leaderboard.map((player, index) => (
              <LeaderboardCard
                key={player.userId}
                rank={index + 1}
                name={player.name}
                avatar={player.avatar}
                winnings={player.totalWinnings}
                gamesPlayed={player.gamesPlayed}
                winRate={player.winRate}
              />
            ))
          ) : (
            <Card style={styles.emptyLeaderboard}>
              <Text style={styles.emptyLeaderboardText}>
                No completed games yet. Play some games to see the leaderboard!
              </Text>
            </Card>
          )}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
  },
  header: {
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 8,
    marginBottom: 16,
    padding: 4,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 6,
  },
  tabButtonActive: {
    backgroundColor: colors.dark.card,
  },
  tabButtonText: {
    fontSize: 16,
    color: colors.dark.textSecondary,
  },
  tabButtonTextActive: {
    color: colors.dark.text,
    fontWeight: '600',
  },
  filterContainer: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  filterButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    marginRight: 8,
    backgroundColor: colors.dark.cardAlt,
  },
  filterButtonActive: {
    backgroundColor: colors.dark.primary,
  },
  filterButtonText: {
    color: colors.dark.textSecondary,
    fontSize: 14,
  },
  filterButtonTextActive: {
    color: colors.dark.background,
    fontWeight: '600',
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  summaryCard: {
    flex: 1,
    marginHorizontal: 4,
    alignItems: 'center',
    paddingVertical: 16,
  },
  summaryIconContainer: {
    marginBottom: 8,
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  summaryLabel: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  profitLossCard: {
    marginBottom: 16,
    padding: 20,
  },
  profitLossHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  profitLossTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginLeft: 8,
  },
  profitLossValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  profitValue: {
    color: colors.dark.success,
  },
  lossValue: {
    color: colors.dark.secondary,
  },
  streakCard: {
    marginBottom: 16,
    padding: 20,
  },
  streakHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  streakTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginLeft: 8,
  },
  streakValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  winStreakValue: {
    color: colors.dark.success,
  },
  lossStreakValue: {
    color: colors.dark.secondary,
  },
  performanceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  performanceCard: {
    flex: 1,
    marginHorizontal: 4,
    padding: 16,
  },
  winCard: {
    borderLeftWidth: 4,
    borderLeftColor: colors.dark.success,
  },
  lossCard: {
    borderLeftWidth: 4,
    borderLeftColor: colors.dark.secondary,
  },
  performanceTitle: {
    fontSize: 16,
    color: colors.dark.textSecondary,
    marginBottom: 8,
  },
  performanceValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  recentGamesSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
  },
  recentGameCard: {
    marginBottom: 8,
    padding: 12,
  },
  recentGameHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  recentGameName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  recentGameDate: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  recentGameDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  recentGameGroup: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  recentGameResult: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  winResult: {
    color: colors.dark.success,
  },
  lossResult: {
    color: colors.dark.secondary,
  },
  leaderboardContainer: {
    marginBottom: 24,
  },
  leaderboardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  leaderboardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginLeft: 8,
  },
  emptyLeaderboard: {
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyLeaderboardText: {
    fontSize: 16,
    color: colors.dark.textSecondary,
    textAlign: 'center',
  },
});