import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { Calendar, Users, Plus, X, Edit } from 'lucide-react-native';
import colors from '@/constants/colors';
import Input from '@/components/Input';
import Button from '@/components/Button';
import Avatar from '@/components/Avatar';
import useStore from '@/store/useStore';
import EditPlayerModal from '@/components/EditPlayerModal';

export default function CreateGameScreen() {
  const { groupId } = useLocalSearchParams<{ groupId?: string }>();
  const { user, groups, createGame } = useStore();
  
  const [name, setName] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState(groupId || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [players, setPlayers] = useState<Array<{ userId: string; name: string; avatar?: string }>>([]);
  const [loading, setLoading] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<{ userId: string; name: string; avatar?: string } | null>(null);
  const [showEditPlayerModal, setShowEditPlayerModal] = useState(false);
  
  useEffect(() => {
    if (groupId) {
      setSelectedGroupId(groupId);
    }
    
    // Add current user as a player
    if (user) {
      setPlayers([
        {
          userId: user.id,
          name: user.name,
          avatar: user.avatar,
        }
      ]);
    }
  }, [groupId, user]);
  
  // Use a state to track if we should redirect
  const [shouldRedirect, setShouldRedirect] = useState(false);

  useEffect(() => {
    // Set a flag instead of redirecting immediately
    if (!user) {
      setShouldRedirect(true);
    }
  }, [user]);

  // Only redirect after component is mounted
  useEffect(() => {
    if (shouldRedirect) {
      // Use a small timeout to ensure layout is mounted
      const timer = setTimeout(() => {
        router.replace('/(auth)/login');
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [shouldRedirect]);
  
  // Load all group members when a group is selected
  useEffect(() => {
    if (selectedGroupId) {
      const selectedGroup = groups.find(g => g.id === selectedGroupId);
      if (selectedGroup) {
        // In a real app, you would fetch all member details from an API
        // For this demo, we'll create dummy players for all members
        const groupPlayers = selectedGroup.members.map(memberId => {
          if (memberId === user?.id) {
            return {
              userId: user.id,
              name: user.name,
              avatar: user.avatar,
            };
          }
          
          // Create dummy player for other members
          return {
            userId: memberId,
            name: `Player ${memberId.substring(0, 4)}`,
            avatar: undefined,
          };
        });
        
        setPlayers(groupPlayers);
      }
    }
  }, [selectedGroupId, groups, user]);
  
  if (!user) return null;
  
  const selectedGroup = groups.find(g => g.id === selectedGroupId);
  
  const handleAddPlayer = () => {
    // In a real app, this would open a modal to select from contacts or group members
    // For demo purposes, we'll add a dummy player
    const playerId = `player-${Date.now()}`;
    const playerName = `Player ${players.length + 1}`;
    
    setPlayers([...players, { userId: playerId, name: playerName }]);
  };
  
  const handleRemovePlayer = (userId: string) => {
    setPlayers(players.filter(p => p.userId !== userId));
  };

  const handleEditPlayer = (player: { userId: string; name: string; avatar?: string }) => {
    setEditingPlayer(player);
    setShowEditPlayerModal(true);
  };

  const handleUpdatePlayer = (updatedPlayer: { userId: string; name: string; avatar?: string }) => {
    setPlayers(players.map(p => 
      p.userId === updatedPlayer.userId ? updatedPlayer : p
    ));
    setEditingPlayer(null);
    setShowEditPlayerModal(false);
  };
  
  const handleSelectGroup = () => {
    // In a real app, this would open a modal to select from user's groups
    if (groups.length === 0) {
      Alert.alert(
        "No Groups",
        "You need to create a group first.",
        [
          {
            text: "Create Group",
            onPress: () => router.push('/group/create'),
          },
          {
            text: "Cancel",
            style: "cancel",
          }
        ]
      );
      return;
    }
    
    Alert.alert(
      "Select Group",
      "Choose a group for this game:",
      [
        ...groups.map(group => ({
          text: group.name,
          onPress: () => setSelectedGroupId(group.id),
        })),
        {
          text: "Cancel",
          style: "cancel",
        }
      ]
    );
  };
  
  const handleCreateGame = () => {
    if (!name.trim()) {
      Alert.alert("Error", "Please enter a game name");
      return;
    }
    
    if (!selectedGroupId) {
      Alert.alert("Error", "Please select a group");
      return;
    }
    
    if (players.length < 2) {
      Alert.alert("Error", "A game needs at least 2 players");
      return;
    }
    
    setLoading(true);
    
    const buyInAmount = selectedGroup?.buyInAmount || 2000; // Default to 2000 if not specified
    
    // Create the game
    createGame({
      name: name.trim(),
      groupId: selectedGroupId,
      date: new Date(date).getTime(),
      players: players.map(player => ({
        userId: player.userId,
        name: player.name,
        avatar: player.avatar,
        initialBuyIn: buyInAmount, // Set default buy-in for all players
        rebuys: [],
        finalChips: 0,
      })),
    });
    
    setLoading(false);
    router.back();
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <Text style={styles.title}>Create New Game</Text>
        <Text style={styles.subtitle}>Set up a new poker game session</Text>
      </View>
      
      <View style={styles.formContainer}>
        <Input
          label="Game Name"
          value={name}
          onChangeText={setName}
          placeholder="Enter game name"
        />
        
        <View style={styles.formGroup}>
          <Text style={styles.label}>Group</Text>
          <TouchableOpacity 
            style={styles.groupSelector}
            onPress={handleSelectGroup}
          >
            {selectedGroup ? (
              <View style={styles.selectedGroup}>
                <Text style={styles.selectedGroupText}>{selectedGroup.name}</Text>
                <Text style={styles.selectedGroupSubtext}>
                  ${selectedGroup.chipValue}/1000 chips
                </Text>
              </View>
            ) : (
              <Text style={styles.placeholderText}>Select a group</Text>
            )}
            <Users size={20} color={colors.dark.textSecondary} />
          </TouchableOpacity>
        </View>
        
        <View style={styles.formGroup}>
          <Text style={styles.label}>Date</Text>
          <TouchableOpacity 
            style={styles.dateSelector}
            onPress={() => {
              // In a real app, this would open a date picker
              Alert.alert("Date Picker", "This would open a date picker in a real app.");
            }}
          >
            <Text style={styles.dateText}>{date}</Text>
            <Calendar size={20} color={colors.dark.textSecondary} />
          </TouchableOpacity>
        </View>
        
        <View style={styles.formGroup}>
          <View style={styles.playersHeader}>
            <Text style={styles.label}>Players</Text>
            <TouchableOpacity 
              style={styles.addPlayerButton}
              onPress={handleAddPlayer}
            >
              <Plus size={16} color={colors.dark.primary} />
              <Text style={styles.addPlayerText}>Add Player</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.playersList}>
            {players.map(player => (
              <View key={player.userId} style={styles.playerItem}>
                <Avatar name={player.name} imageUrl={player.avatar} size={36} />
                <Text style={styles.playerName}>{player.name}</Text>
                
                <View style={styles.playerActions}>
                  <TouchableOpacity 
                    style={styles.editPlayerButton}
                    onPress={() => handleEditPlayer(player)}
                  >
                    <Edit size={16} color={colors.dark.primary} />
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={styles.removePlayerButton}
                    onPress={() => handleRemovePlayer(player.userId)}
                  >
                    <X size={16} color={colors.dark.error} />
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
          
          {selectedGroup && (
            <View style={styles.infoBox}>
              <Text style={styles.infoText}>
                All players will start with {selectedGroup.buyInAmount || 2000} chips.
              </Text>
            </View>
          )}
        </View>
        
        <Button
          title="Create Game"
          onPress={handleCreateGame}
          loading={loading}
          style={styles.createButton}
        />
        
        <Button
          title="Cancel"
          onPress={() => router.back()}
          variant="ghost"
          disabled={loading}
        />
      </View>

      {/* Edit Player Modal */}
      <EditPlayerModal
        visible={showEditPlayerModal}
        player={editingPlayer}
        onClose={() => setShowEditPlayerModal(false)}
        onSave={handleUpdatePlayer}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.dark.textSecondary,
  },
  formContainer: {
    marginBottom: 24,
  },
  formGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    color: colors.dark.text,
    fontWeight: '500',
  },
  groupSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: colors.dark.border,
    borderRadius: 12,
    backgroundColor: colors.dark.cardAlt,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  selectedGroup: {
    flex: 1,
  },
  selectedGroupText: {
    fontSize: 16,
    color: colors.dark.text,
  },
  selectedGroupSubtext: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginTop: 2,
  },
  placeholderText: {
    fontSize: 16,
    color: colors.dark.textSecondary,
  },
  dateSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: colors.dark.border,
    borderRadius: 12,
    backgroundColor: colors.dark.cardAlt,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  dateText: {
    fontSize: 16,
    color: colors.dark.text,
  },
  playersHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  addPlayerButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  addPlayerText: {
    color: colors.dark.primary,
    marginLeft: 4,
    fontWeight: '500',
  },
  playersList: {
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.dark.border,
    padding: 8,
  },
  playerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  playerName: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: colors.dark.text,
  },
  playerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  editPlayerButton: {
    padding: 8,
    marginRight: 4,
  },
  removePlayerButton: {
    padding: 8,
  },
  infoBox: {
    marginTop: 12,
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 8,
    padding: 12,
    borderLeftWidth: 4,
    borderLeftColor: colors.dark.primary,
  },
  infoText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  createButton: {
    marginTop: 16,
    marginBottom: 12,
  },
});