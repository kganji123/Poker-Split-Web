import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { 
  Users, 
  Clock, 
  DollarSign, 
  Calculator, 
  ChevronRight,
  Trash2,
  Settings,
  Edit,
  RefreshCw,
  Award,
  ChevronDown,
  ChevronUp,
  Plus
} from 'lucide-react-native';
import colors from '@/constants/colors';
import useStore from '@/store/useStore';
import Card from '@/components/Card';
import Button from '@/components/Button';
import PlayerCard from '@/components/PlayerCard';
import Avatar from '@/components/Avatar';
import RecordWinModal from '@/components/RecordWinModal';

export default function GameDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { 
    user, 
    games, 
    groups, 
    activeGame,
    setActiveGame,
    endGame,
    deleteGame,
    calculateSettlements,
    addRebuy,
    updateGame
  } = useStore();
  
  const [showSettings, setShowSettings] = useState(false);
  const [showGameProgress, setShowGameProgress] = useState(false);
  const [showRecordWinModal, setShowRecordWinModal] = useState(false);
  
  useEffect(() => {
    if (id) {
      setActiveGame(id);
    }
  }, [id, setActiveGame]);
  
  if (!id || !user) return null;
  
  const game = games.find(g => g.id === id);
  if (!game) {
    // Use setTimeout to avoid navigation during render
    setTimeout(() => {
      router.back();
    }, 0);
    return null;
  }
  
  const group = groups.find(g => g.id === game.groupId);
  if (!group) {
    // Use setTimeout to avoid navigation during render
    setTimeout(() => {
      router.back();
    }, 0);
    return null;
  }
  
  const isAdmin = group.adminId === user.id;
  const isActive = game.isActive;
  
  // Get game rounds and stats
  const gameRounds = game.rounds || [];
  const playerWins = {};
  const playerRebuys = {};
  
  // Initialize player stats
  game.players.forEach(player => {
    playerWins[player.userId] = 0;
    playerRebuys[player.userId] = player.rebuys.length;
  });
  
  // Count wins from rounds
  gameRounds.forEach(round => {
    if (round.winnerId && playerWins[round.winnerId] !== undefined) {
      playerWins[round.winnerId]++;
    }
  });
  
  // Sort players by wins for leaderboard
  const leaderboardPlayers = [...game.players].sort((a, b) => {
    const aWins = playerWins[a.userId] || 0;
    const bWins = playerWins[b.userId] || 0;
    return bWins - aWins;
  });
  
  // Sort players by rebuys
  const rebuyLeaderboardPlayers = [...game.players].sort((a, b) => {
    const aRebuys = playerRebuys[a.userId] || 0;
    const bRebuys = playerRebuys[b.userId] || 0;
    return bRebuys - aRebuys;
  });
  
  const handleEndGame = () => {
    // Check if all players have final chips entered
    const missingFinalChips = game.players.filter(player => player.finalChips === 0);
    
    if (missingFinalChips.length > 0) {
      Alert.alert(
        "Missing Final Chips",
        `${missingFinalChips.length} player(s) don't have final chip counts. Please update all players' final chips before ending the game.`,
        [{ text: "OK" }]
      );
      return;
    }
    
    Alert.alert(
      "End Game",
      "Are you sure you want to end this game? This will calculate final settlements.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "End Game", 
          onPress: () => {
            endGame(id);
          }
        }
      ]
    );
  };
  
  const handleDeleteGame = () => {
    Alert.alert(
      "Delete Game",
      "Are you sure you want to delete this game? All data will be lost.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Delete", 
          onPress: () => {
            deleteGame(id);
            router.back();
          },
          style: "destructive"
        }
      ]
    );
  };
  
  const handleCalculateSettlements = () => {
    calculateSettlements(id);
    router.push(`/game/${id}/settlements`);
  };
  
  const handleEditGame = () => {
    // For completed games, allow admin to edit
    if (!isActive && isAdmin) {
      Alert.alert(
        "Edit Game",
        "What would you like to edit?",
        [
          {
            text: "Edit Player Chips",
            onPress: () => {
              // Navigate to a screen where admin can edit player chips
              Alert.alert("Edit Players", "You can update player chips by selecting individual players.");
            }
          },
          {
            text: "Recalculate Settlements",
            onPress: () => {
              calculateSettlements(id);
              Alert.alert("Settlements Recalculated", "The settlements have been recalculated based on current values.");
            }
          },
          {
            text: "Cancel",
            style: "cancel"
          }
        ]
      );
    }
  };
  
  const handleQuickRebuy = (playerId) => {
    const buyInAmount = group.buyInAmount || 2000;
    addRebuy(id, playerId, buyInAmount);
    Alert.alert("Success", `Rebuy of ${buyInAmount} chips added for player`);
  };
  
  const handleRecordWin = (playerId, handType) => {
    // Add a new round to the game
    const newRound = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      winnerId: playerId,
      handType: handType,
    };
    
    const updatedRounds = [...(game.rounds || []), newRound];
    updateGame(id, { rounds: updatedRounds });
    
    setShowRecordWinModal(false);
    Alert.alert("Success", "Win recorded successfully");
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <Stack.Screen 
        options={{
          title: game.name,
          headerRight: () => (
            isAdmin ? (
              <TouchableOpacity 
                onPress={() => setShowSettings(!showSettings)}
                style={styles.headerButton}
              >
                <Settings size={24} color={colors.dark.text} />
              </TouchableOpacity>
            ) : null
          ),
        }} 
      />
      
      {/* Game Info Card */}
      <Card style={styles.infoCard}>
        <View style={styles.infoRow}>
          <View style={styles.infoIconContainer}>
            <Users size={20} color={colors.dark.primary} />
          </View>
          <Text style={styles.infoLabel}>Group:</Text>
          <Text style={styles.infoValue}>{group.name}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <View style={styles.infoIconContainer}>
            <Clock size={20} color={colors.dark.primary} />
          </View>
          <Text style={styles.infoLabel}>Date:</Text>
          <Text style={styles.infoValue}>
            {new Date(game.date).toLocaleDateString()}
          </Text>
        </View>
        
        <View style={styles.infoRow}>
          <View style={styles.infoIconContainer}>
            <DollarSign size={20} color={colors.dark.primary} />
          </View>
          <Text style={styles.infoLabel}>Chip Value:</Text>
          <Text style={styles.infoValue}>${group.chipValue} per 1000 chips</Text>
        </View>
        
        <View style={styles.infoRow}>
          <View style={styles.infoIconContainer}>
            <Users size={20} color={colors.dark.primary} />
          </View>
          <Text style={styles.infoLabel}>Players:</Text>
          <Text style={styles.infoValue}>{game.players.length}</Text>
        </View>
        
        <View style={styles.statusContainer}>
          <View style={[
            styles.statusBadge,
            isActive ? styles.activeBadge : styles.completedBadge
          ]}>
            <Text style={[
              styles.statusText,
              isActive ? styles.activeText : styles.completedText
            ]}>
              {isActive ? 'Active' : 'Completed'}
            </Text>
          </View>
        </View>
      </Card>
      
      {/* Settings Panel (Admin only) */}
      {showSettings && isAdmin && (
        <Card style={styles.settingsCard}>
          <Text style={styles.settingsTitle}>Game Settings</Text>
          
          {isActive && (
            <TouchableOpacity 
              style={styles.settingsOption}
              onPress={handleEndGame}
            >
              <Calculator size={20} color={colors.dark.primary} />
              <Text style={styles.settingsOptionText}>End Game & Calculate Settlements</Text>
              <ChevronRight size={16} color={colors.dark.textSecondary} />
            </TouchableOpacity>
          )}
          
          {!isActive && (
            <TouchableOpacity 
              style={styles.settingsOption}
              onPress={handleEditGame}
            >
              <Edit size={20} color={colors.dark.primary} />
              <Text style={styles.settingsOptionText}>Edit Game & Recalculate</Text>
              <ChevronRight size={16} color={colors.dark.textSecondary} />
            </TouchableOpacity>
          )}
          
          <TouchableOpacity 
            style={[styles.settingsOption, styles.deleteOption]}
            onPress={handleDeleteGame}
          >
            <Trash2 size={20} color={colors.dark.error} />
            <Text style={[styles.settingsOptionText, styles.deleteText]}>Delete Game</Text>
          </TouchableOpacity>
        </Card>
      )}
      
      {/* Active Game Leaderboard */}
      {isActive && (
        <Card style={styles.leaderboardCard}>
          <Text style={styles.sectionTitle}>Game Leaderboard</Text>
          
          <View style={styles.leaderboardTabs}>
            <Text style={styles.leaderboardTabTitle}>Most Wins</Text>
          </View>
          
          <View style={styles.leaderboardList}>
            {leaderboardPlayers.slice(0, 3).map((player, index) => (
              <View key={player.userId} style={styles.leaderboardItem}>
                <View style={styles.leaderboardRank}>
                  <Text style={styles.leaderboardRankText}>{index + 1}</Text>
                </View>
                <Avatar name={player.name} imageUrl={player.avatar} size={36} />
                <Text style={styles.leaderboardPlayerName}>{player.name}</Text>
                <Text style={styles.leaderboardStat}>
                  {playerWins[player.userId] || 0} {playerWins[player.userId] === 1 ? 'win' : 'wins'}
                </Text>
              </View>
            ))}
          </View>
          
          <View style={styles.leaderboardTabs}>
            <Text style={styles.leaderboardTabTitle}>Most Rebuys</Text>
          </View>
          
          <View style={styles.leaderboardList}>
            {rebuyLeaderboardPlayers.slice(0, 3).map((player, index) => (
              <View key={player.userId} style={styles.leaderboardItem}>
                <View style={styles.leaderboardRank}>
                  <Text style={styles.leaderboardRankText}>{index + 1}</Text>
                </View>
                <Avatar name={player.name} imageUrl={player.avatar} size={36} />
                <Text style={styles.leaderboardPlayerName}>{player.name}</Text>
                <Text style={styles.leaderboardStat}>
                  {playerRebuys[player.userId] || 0} {playerRebuys[player.userId] === 1 ? 'rebuy' : 'rebuys'}
                </Text>
              </View>
            ))}
          </View>
          
          {isActive && (
            <Button
              title="Record Win"
              onPress={() => setShowRecordWinModal(true)}
              style={styles.recordWinButton}
              icon={<Award size={16} color={colors.dark.background} />}
            />
          )}
        </Card>
      )}
      
      {/* Game Progress (Expandable) */}
      {isActive && (
        <Card style={styles.progressCard}>
          <TouchableOpacity 
            style={styles.progressHeader}
            onPress={() => setShowGameProgress(!showGameProgress)}
          >
            <Text style={styles.progressTitle}>Game Progress</Text>
            {showGameProgress ? (
              <ChevronUp size={20} color={colors.dark.text} />
            ) : (
              <ChevronDown size={20} color={colors.dark.text} />
            )}
          </TouchableOpacity>
          
          {showGameProgress && (
            <View style={styles.progressContent}>
              {gameRounds.length > 0 ? (
                <View>
                  {gameRounds.slice().reverse().map((round, index) => {
                    const winner = game.players.find(p => p.userId === round.winnerId);
                    return (
                      <View key={round.id} style={styles.roundItem}>
                        <View style={styles.roundHeader}>
                          <View style={styles.roundWinner}>
                            <Award size={16} color={colors.dark.gold} />
                            <Text style={styles.roundWinnerText}>
                              {winner ? winner.name : 'Unknown'} won with {round.handType || 'a hand'}
                            </Text>
                          </View>
                          <Text style={styles.roundTime}>
                            {new Date(round.timestamp).toLocaleTimeString()}
                          </Text>
                        </View>
                        <Text style={styles.roundDate}>
                          {new Date(round.timestamp).toLocaleDateString()}
                        </Text>
                      </View>
                    );
                  })}
                </View>
              ) : (
                <Text style={styles.noProgressText}>No rounds recorded yet. Use the "Record Win" button to track game progress.</Text>
              )}
              
              <View style={styles.rebuyHistory}>
                <Text style={styles.rebuyHistoryTitle}>Rebuy History</Text>
                {game.players.some(p => p.rebuys.length > 0) ? (
                  game.players.map(player => {
                    if (player.rebuys.length === 0) return null;
                    
                    return (
                      <View key={player.userId} style={styles.playerRebuyItem}>
                        <Text style={styles.playerRebuyName}>{player.name}:</Text>
                        <Text style={styles.playerRebuyCount}>
                          {player.rebuys.length} {player.rebuys.length === 1 ? 'rebuy' : 'rebuys'}
                        </Text>
                      </View>
                    );
                  })
                ) : (
                  <Text style={styles.noProgressText}>No rebuys recorded yet.</Text>
                )}
              </View>
            </View>
          )}
        </Card>
      )}
      
      {/* Players Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Players</Text>
        
        {game.players.map(player => (
          <View key={player.userId} style={styles.playerCardContainer}>
            <PlayerCard
              player={player}
              chipValue={group.chipValue}
              showResult={!isActive}
              onPress={() => router.push(`/game/${id}/player/${player.userId}`)}
            />
            
            {isActive && (
              <View style={styles.quickActions}>
                <TouchableOpacity 
                  style={styles.quickActionButton}
                  onPress={() => handleQuickRebuy(player.userId)}
                >
                  <RefreshCw size={16} color={colors.dark.text} />
                  <Text style={styles.quickActionText}>Rebuy</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        ))}
      </View>
      
      {/* Action Buttons */}
      <View style={styles.actionsContainer}>
        {isActive ? (
          <>
            <Button
              title="Update Chips"
              onPress={() => router.push(`/game/${id}/player/${user.id}`)}
              style={styles.actionButton}
            />
            
            {isAdmin && (
              <Button
                title="End Game"
                onPress={handleEndGame}
                variant="secondary"
                style={styles.actionButton}
              />
            )}
          </>
        ) : (
          <>
            <Button
              title="View Settlements"
              onPress={() => router.push(`/game/${id}/settlements`)}
              style={styles.actionButton}
            />
            
            {isAdmin && (
              <Button
                title="Recalculate Settlements"
                onPress={handleCalculateSettlements}
                variant="outline"
                style={styles.actionButton}
              />
            )}
          </>
        )}
      </View>
      
      {/* Record Win Modal */}
      <RecordWinModal
        visible={showRecordWinModal}
        onClose={() => setShowRecordWinModal(false)}
        players={game.players}
        onRecordWin={handleRecordWin}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  headerButton: {
    padding: 8,
  },
  infoCard: {
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.dark.cardAlt,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  infoLabel: {
    fontSize: 16,
    color: colors.dark.textSecondary,
    width: 100,
  },
  infoValue: {
    fontSize: 16,
    color: colors.dark.text,
    fontWeight: '500',
    flex: 1,
  },
  statusContainer: {
    alignItems: 'center',
    marginTop: 8,
  },
  statusBadge: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
  },
  activeBadge: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
  },
  completedBadge: {
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
  },
  statusText: {
    fontWeight: 'bold',
    fontSize: 14,
  },
  activeText: {
    color: colors.dark.success,
  },
  completedText: {
    color: colors.dark.primary,
  },
  settingsCard: {
    marginBottom: 16,
  },
  settingsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  settingsOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  settingsOptionText: {
    fontSize: 16,
    color: colors.dark.text,
    flex: 1,
    marginLeft: 12,
  },
  deleteOption: {
    borderBottomWidth: 0,
    marginTop: 8,
  },
  deleteText: {
    color: colors.dark.error,
  },
  leaderboardCard: {
    marginBottom: 16,
  },
  leaderboardTabs: {
    marginBottom: 12,
  },
  leaderboardTabTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.primary,
    marginBottom: 8,
  },
  leaderboardList: {
    marginBottom: 16,
  },
  leaderboardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  leaderboardRank: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.dark.cardAlt,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  leaderboardRankText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  leaderboardPlayerName: {
    fontSize: 16,
    color: colors.dark.text,
    flex: 1,
    marginLeft: 12,
  },
  leaderboardStat: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.dark.primary,
  },
  recordWinButton: {
    marginTop: 8,
  },
  progressCard: {
    marginBottom: 16,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  progressTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  progressContent: {
    marginTop: 16,
  },
  roundItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  roundHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  roundWinner: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  roundWinnerText: {
    fontSize: 16,
    color: colors.dark.text,
    marginLeft: 8,
  },
  roundTime: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  roundDate: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  noProgressText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    fontStyle: 'italic',
    textAlign: 'center',
    marginVertical: 16,
  },
  rebuyHistory: {
    marginTop: 16,
  },
  rebuyHistoryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
  },
  playerRebuyItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  playerRebuyName: {
    fontSize: 16,
    color: colors.dark.text,
  },
  playerRebuyCount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.primary,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 12,
  },
  playerCardContainer: {
    marginBottom: 8,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: -8,
    marginBottom: 8,
  },
  quickActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dark.primary,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
  },
  quickActionText: {
    color: colors.dark.text,
    fontWeight: '600',
    fontSize: 12,
    marginLeft: 4,
  },
  actionsContainer: {
    marginTop: 8,
    marginBottom: 24,
  },
  actionButton: {
    marginBottom: 12,
  },
});