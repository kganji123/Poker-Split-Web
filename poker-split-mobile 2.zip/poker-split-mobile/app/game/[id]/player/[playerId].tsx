import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { Clock, RefreshCw } from 'lucide-react-native';
import colors from '@/constants/colors';
import useStore from '@/store/useStore';
import Card from '@/components/Card';
import Button from '@/components/Button';
import ChipInput from '@/components/ChipInput';
import Avatar from '@/components/Avatar';

export default function PlayerDetailsScreen() {
  const { id, playerId } = useLocalSearchParams<{ id: string; playerId: string }>();
  const { 
    games, 
    groups, 
    updatePlayerBuyIn, 
    addRebuy, 
    updateFinalChips 
  } = useStore();
  
  const [finalChips, setFinalChips] = useState(0);
  
  if (!id || !playerId) return null;
  
  const game = games.find(g => g.id === id);
  if (!game) {
    // Use setTimeout to avoid navigation during render
    setTimeout(() => {
      router.back();
    }, 0);
    return null;
  }
  
  const player = game.players.find(p => p.userId === playerId);
  if (!player) {
    // Use setTimeout to avoid navigation during render
    setTimeout(() => {
      router.back();
    }, 0);
    return null;
  }
  
  const group = groups.find(g => g.id === game.groupId);
  if (!group) {
    // Use setTimeout to avoid navigation during render
    setTimeout(() => {
      router.back();
    }, 0);
    return null;
  }
  
  // Initialize state from player data
  useEffect(() => {
    setFinalChips(player.finalChips);
  }, [player]);
  
  const buyInAmount = group.buyInAmount || 2000; // Default to 2000 if not specified
  const totalRebuys = player.rebuys.reduce((sum, rebuy) => sum + rebuy.amount, 0);
  const totalBuyIn = player.initialBuyIn + totalRebuys;
  
  const handleAddRebuy = () => {
    addRebuy(id, playerId, buyInAmount);
    Alert.alert("Success", `Rebuy of ${buyInAmount} chips added successfully`);
  };
  
  const handleUpdateFinalChips = () => {
    if (finalChips === 0) {
      Alert.alert(
        "Confirm Zero Chips",
        "Are you sure you want to set final chips to 0? This means the player lost all their chips.",
        [
          {
            text: "Cancel",
            style: "cancel"
          },
          {
            text: "Confirm",
            onPress: () => {
              updateFinalChips(id, playerId, finalChips);
              Alert.alert("Success", "Final chips updated successfully");
            }
          }
        ]
      );
    } else {
      updateFinalChips(id, playerId, finalChips);
      Alert.alert("Success", "Final chips updated successfully");
    }
  };
  
  // Calculate net result if game is active and final chips are set
  const netChips = finalChips - totalBuyIn;
  const netResult = netChips * (group.chipValue / 1000); // Convert to dollars

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <Stack.Screen options={{ title: player.name }} />
      
      {/* Player Info Card */}
      <Card style={styles.playerCard}>
        <View style={styles.playerHeader}>
          <Avatar name={player.name} imageUrl={player.avatar} size={80} />
          <View style={styles.playerInfo}>
            <Text style={styles.playerName}>{player.name}</Text>
            
            {game.isActive ? (
              <View style={styles.activeBadge}>
                <Text style={styles.activeBadgeText}>Active Game</Text>
              </View>
            ) : (
              <View style={styles.completedBadge}>
                <Text style={styles.completedBadgeText}>Game Completed</Text>
              </View>
            )}
          </View>
        </View>
        
        <View style={styles.chipSummary}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Initial Buy-in</Text>
            <Text style={styles.summaryValue}>{player.initialBuyIn}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Total Rebuys</Text>
            <Text style={styles.summaryValue}>{totalRebuys}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Final Chips</Text>
            <Text style={styles.summaryValue}>{player.finalChips || '-'}</Text>
          </View>
        </View>
        
        {!game.isActive && player.netResult !== undefined && (
          <View style={styles.resultContainer}>
            <Text style={styles.resultLabel}>Net Result</Text>
            <Text style={[
              styles.resultValue,
              player.netResult > 0 ? styles.winResult : player.netResult < 0 ? styles.lossResult : null,
            ]}>
              {player.netResult > 0 ? '+' : ''}{player.netResult.toFixed(2)}
            </Text>
          </View>
        )}
      </Card>
      
      {/* Update Chips Section */}
      {game.isActive && (
        <Card style={styles.updateCard}>
          <Text style={styles.sectionTitle}>Update Chips</Text>
          
          <View style={styles.inputSection}>
            <View style={styles.inputSectionHeader}>
              <Text style={styles.inputSectionTitle}>Add Rebuy</Text>
              <View style={styles.rebuyCountBadge}>
                <Text style={styles.rebuyCountText}>
                  {player.rebuys.length} {player.rebuys.length === 1 ? 'rebuy' : 'rebuys'}
                </Text>
              </View>
            </View>
            
            <View style={styles.rebuyInfo}>
              <RefreshCw size={20} color={colors.dark.primary} />
              <Text style={styles.rebuyInfoText}>
                Each rebuy adds {buyInAmount} chips
              </Text>
            </View>
            
            <Button
              title={`Add Rebuy (${buyInAmount} chips)`}
              onPress={handleAddRebuy}
              size="medium"
              style={styles.rebuyButton}
            />
          </View>
          
          <View style={styles.divider} />
          
          <View style={styles.inputSection}>
            <Text style={styles.inputSectionTitle}>Final Chips</Text>
            <ChipInput
              label="Chips"
              value={finalChips}
              onChange={setFinalChips}
              step={500}
            />
            <Button
              title="Update Final Chips"
              onPress={handleUpdateFinalChips}
              size="small"
            />
          </View>
          
          {finalChips > 0 && (
            <View style={styles.previewContainer}>
              <Text style={styles.previewTitle}>Result Preview</Text>
              <View style={styles.previewContent}>
                <View style={styles.previewItem}>
                  <Text style={styles.previewLabel}>Total Buy-in:</Text>
                  <Text style={styles.previewValue}>{totalBuyIn} chips</Text>
                </View>
                <View style={styles.previewItem}>
                  <Text style={styles.previewLabel}>Final Chips:</Text>
                  <Text style={styles.previewValue}>{finalChips} chips</Text>
                </View>
                <View style={styles.previewItem}>
                  <Text style={styles.previewLabel}>Net Chips:</Text>
                  <Text style={[
                    styles.previewValue,
                    netChips > 0 ? styles.positiveValue : netChips < 0 ? styles.negativeValue : null,
                  ]}>
                    {netChips > 0 ? '+' : ''}{netChips} chips
                  </Text>
                </View>
                <View style={styles.previewItem}>
                  <Text style={styles.previewLabel}>Net Result:</Text>
                  <Text style={[
                    styles.previewValue,
                    netResult > 0 ? styles.positiveValue : netResult < 0 ? styles.negativeValue : null,
                  ]}>
                    {netResult > 0 ? '+' : ''}${netResult.toFixed(2)}
                  </Text>
                </View>
              </View>
            </View>
          )}
        </Card>
      )}
      
      {/* Rebuys History */}
      {player.rebuys.length > 0 && (
        <Card style={styles.historyCard}>
          <Text style={styles.sectionTitle}>Rebuy History</Text>
          
          {player.rebuys.map((rebuy, index) => (
            <View key={index} style={styles.rebuyItem}>
              <View style={styles.rebuyInfo}>
                <Text style={styles.rebuyAmount}>{rebuy.amount} chips</Text>
                <View style={styles.rebuyTime}>
                  <Clock size={14} color={colors.dark.textSecondary} />
                  <Text style={styles.rebuyTimeText}>
                    {new Date(rebuy.timestamp).toLocaleTimeString()}
                  </Text>
                </View>
              </View>
              <Text style={styles.rebuyDate}>
                {new Date(rebuy.timestamp).toLocaleDateString()}
              </Text>
            </View>
          ))}
        </Card>
      )}
      
      {/* Back Button */}
      <Button
        title="Back to Game"
        onPress={() => router.back()}
        variant="outline"
        style={styles.backButton}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  playerCard: {
    marginBottom: 16,
  },
  playerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  playerInfo: {
    marginLeft: 16,
    flex: 1,
  },
  playerName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  activeBadge: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  activeBadgeText: {
    color: colors.dark.success,
    fontWeight: '600',
    fontSize: 12,
  },
  completedBadge: {
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  completedBadgeText: {
    color: colors.dark.primary,
    fontWeight: '600',
    fontSize: 12,
  },
  chipSummary: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  summaryItem: {
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: 12,
    color: colors.dark.textSecondary,
    marginBottom: 4,
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  resultContainer: {
    alignItems: 'center',
    marginTop: 8,
  },
  resultLabel: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginBottom: 4,
  },
  resultValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  winResult: {
    color: colors.dark.success,
  },
  lossResult: {
    color: colors.dark.error,
  },
  updateCard: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  inputSection: {
    marginBottom: 16,
  },
  inputSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  inputSectionTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.dark.text,
    marginBottom: 8,
  },
  rebuyCountBadge: {
    backgroundColor: colors.dark.cardAlt,
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
  },
  rebuyCountText: {
    fontSize: 12,
    color: colors.dark.textSecondary,
    fontWeight: '500',
  },
  rebuyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  rebuyInfoText: {
    marginLeft: 8,
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  rebuyButton: {
    marginTop: 8,
  },
  divider: {
    height: 1,
    backgroundColor: colors.dark.border,
    marginVertical: 16,
  },
  previewContainer: {
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 8,
    padding: 16,
    marginTop: 16,
  },
  previewTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 12,
  },
  previewContent: {
    gap: 8,
  },
  previewItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  previewLabel: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  previewValue: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.dark.text,
  },
  positiveValue: {
    color: colors.dark.success,
  },
  negativeValue: {
    color: colors.dark.error,
  },
  historyCard: {
    marginBottom: 16,
  },
  rebuyItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  rebuyInfo: {
    flex: 1,
  },
  rebuyAmount: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.dark.text,
    marginBottom: 4,
  },
  rebuyTime: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rebuyTimeText: {
    fontSize: 12,
    color: colors.dark.textSecondary,
    marginLeft: 4,
  },
  rebuyDate: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  backButton: {
    marginBottom: 24,
  },
});