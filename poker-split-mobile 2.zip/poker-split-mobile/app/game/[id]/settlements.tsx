import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { Share2, ArrowDown, ArrowUp, DollarSign, CheckCircle } from 'lucide-react-native';
import colors from '@/constants/colors';
import useStore from '@/store/useStore';
import Card from '@/components/Card';
import Button from '@/components/Button';
import SettlementCard from '@/components/SettlementCard';
import PlayerCard from '@/components/PlayerCard';

export default function SettlementsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { games, groups, markSettlementAsSettled } = useStore();
  const [showResults, setShowResults] = useState(true);
  
  if (!id) return null;
  
  const game = games.find(g => g.id === id);
  if (!game) {
    // Use setTimeout to avoid navigation during render
    setTimeout(() => {
      router.back();
    }, 0);
    return null;
  }
  
  const group = groups.find(g => g.id === game.groupId);
  if (!group) {
    // Use setTimeout to avoid navigation during render
    setTimeout(() => {
      router.back();
    }, 0);
    return null;
  }
  
  const settlements = game.settlements || [];
  const playersWithResults = game.players.filter(p => p.netResult !== undefined)
    .sort((a, b) => (b.netResult || 0) - (a.netResult || 0));
  
  const winners = playersWithResults.filter(p => (p.netResult || 0) > 0);
  const losers = playersWithResults.filter(p => (p.netResult || 0) < 0);
  
  const totalSettled = settlements.filter(s => s.settled).length;
  const allSettled = totalSettled === settlements.length && settlements.length > 0;
  
  const handleMarkSettled = (fromId: string, toId: string) => {
    markSettlementAsSettled(id, fromId, toId);
  };
  
  const handleShare = () => {
    // Generate a text summary of all settlements
    let message = `Settlements for ${game.name} (${new Date(game.date).toLocaleDateString()}):\n\n`;
    
    if (settlements.length === 0) {
      message += "No settlements required.";
    } else {
      settlements.forEach((settlement, index) => {
        const fromPlayer = game.players.find(p => p.userId === settlement.fromPlayerId);
        const toPlayer = game.players.find(p => p.userId === settlement.toPlayerId);
        
        if (fromPlayer && toPlayer) {
          message += `${index + 1}. ${fromPlayer.name} pays ${toPlayer.name}: $${settlement.amount.toFixed(2)}`;
          message += settlement.settled ? " (Settled)" : " (Pending)";
          message += "\n";
        }
      });
    }
    
    Alert.alert(
      "Share Settlements",
      "Here's a summary of all settlements:",
      [
        {
          text: "Copy to Clipboard",
          onPress: () => {
            Alert.alert("Copied", "Settlement details copied to clipboard");
          }
        },
        {
          text: "Share",
          onPress: () => {
            Alert.alert("Share", "This would open the share dialog in a real app");
          }
        },
        {
          text: "Cancel",
          style: "cancel"
        }
      ]
    );
  };

  const markAllSettled = () => {
    Alert.alert(
      "Mark All Settled",
      "Are you sure you want to mark all settlements as settled?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        {
          text: "Mark All",
          onPress: () => {
            settlements.forEach(settlement => {
              if (!settlement.settled) {
                markSettlementAsSettled(id, settlement.fromPlayerId, settlement.toPlayerId);
              }
            });
          }
        }
      ]
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <Stack.Screen 
        options={{
          title: "Settlements",
          headerRight: () => (
            <TouchableOpacity 
              onPress={handleShare}
              style={styles.headerButton}
            >
              <Share2 size={24} color={colors.dark.text} />
            </TouchableOpacity>
          ),
        }} 
      />
      
      {/* Summary Card */}
      <Card style={styles.summaryCard}>
        <Text style={styles.gameName}>{game.name}</Text>
        <Text style={styles.gameDate}>
          {new Date(game.date).toLocaleDateString()}
        </Text>
        
        <View style={styles.settlementProgress}>
          <View style={styles.progressLabel}>
            <Text style={styles.progressText}>
              Settlements: {totalSettled}/{settlements.length}
            </Text>
            {allSettled && (
              <View style={styles.completeBadge}>
                <Text style={styles.completeBadgeText}>Complete</Text>
              </View>
            )}
          </View>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill,
                { width: `${settlements.length ? (totalSettled / settlements.length) * 100 : 0}%` }
              ]} 
            />
          </View>
        </View>
      </Card>
      
      {/* Toggle Buttons */}
      <View style={styles.toggleContainer}>
        <TouchableOpacity
          style={[
            styles.toggleButton,
            showResults ? styles.toggleButtonActive : null,
          ]}
          onPress={() => setShowResults(true)}
        >
          <Text
            style={[
              styles.toggleButtonText,
              showResults ? styles.toggleButtonTextActive : null,
            ]}
          >
            Results
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.toggleButton,
            !showResults ? styles.toggleButtonActive : null,
          ]}
          onPress={() => setShowResults(false)}
        >
          <Text
            style={[
              styles.toggleButtonText,
              !showResults ? styles.toggleButtonTextActive : null,
            ]}
          >
            Settlements
          </Text>
        </TouchableOpacity>
      </View>
      
      {/* Results View */}
      {showResults && (
        <View style={styles.resultsContainer}>
          {winners.length > 0 && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <ArrowUp size={20} color={colors.dark.success} />
                <Text style={styles.sectionTitle}>Winners</Text>
              </View>
              
              {winners.map(player => (
                <PlayerCard
                  key={player.userId}
                  player={player}
                  chipValue={group.chipValue}
                  showResult={true}
                />
              ))}
            </View>
          )}
          
          {losers.length > 0 && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <ArrowDown size={20} color={colors.dark.error} />
                <Text style={styles.sectionTitle}>Losers</Text>
              </View>
              
              {losers.map(player => (
                <PlayerCard
                  key={player.userId}
                  player={player}
                  chipValue={group.chipValue}
                  showResult={true}
                />
              ))}
            </View>
          )}
        </View>
      )}
      
      {/* Settlements View */}
      {!showResults && (
        <View style={styles.settlementsContainer}>
          {settlements.length > 0 ? (
            <>
              <View style={styles.settlementHeader}>
                <Text style={styles.settlementTitle}>Payment Details</Text>
                {!allSettled && settlements.length > 1 && (
                  <TouchableOpacity 
                    style={styles.markAllButton}
                    onPress={markAllSettled}
                  >
                    <CheckCircle size={16} color={colors.dark.primary} />
                    <Text style={styles.markAllText}>Mark All Settled</Text>
                  </TouchableOpacity>
                )}
              </View>
              
              <Card style={styles.paymentInstructions}>
                <Text style={styles.instructionsTitle}>Who Pays Whom</Text>
                <Text style={styles.instructionsText}>
                  Players on the left need to pay the amount shown to players on the right.
                  Mark each payment as settled once completed.
                </Text>
              </Card>
              
              {settlements.map((settlement, index) => {
                const fromPlayer = game.players.find(p => p.userId === settlement.fromPlayerId);
                const toPlayer = game.players.find(p => p.userId === settlement.toPlayerId);
                
                if (!fromPlayer || !toPlayer) return null;
                
                return (
                  <SettlementCard
                    key={index}
                    settlement={settlement}
                    fromPlayer={fromPlayer}
                    toPlayer={toPlayer}
                    onMarkSettled={() => handleMarkSettled(settlement.fromPlayerId, settlement.toPlayerId)}
                  />
                );
              })}
            </>
          ) : (
            <Card style={styles.emptyCard}>
              <View style={styles.emptyContent}>
                <DollarSign size={48} color={colors.dark.textSecondary} />
                <Text style={styles.emptyTitle}>No Settlements</Text>
                <Text style={styles.emptyMessage}>
                  There are no settlements to display for this game.
                </Text>
              </View>
            </Card>
          )}
        </View>
      )}
      
      {/* Back Button */}
      <Button
        title="Back to Game"
        onPress={() => router.back()}
        variant="outline"
        style={styles.backButton}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  headerButton: {
    padding: 8,
  },
  summaryCard: {
    marginBottom: 16,
  },
  gameName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  gameDate: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginBottom: 16,
  },
  settlementProgress: {
    marginTop: 8,
  },
  progressLabel: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
  },
  completeBadge: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
  },
  completeBadgeText: {
    color: colors.dark.success,
    fontWeight: '600',
    fontSize: 12,
  },
  progressBar: {
    height: 8,
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.dark.primary,
    borderRadius: 4,
  },
  toggleContainer: {
    flexDirection: 'row',
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 8,
    marginBottom: 16,
    padding: 4,
  },
  toggleButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 6,
  },
  toggleButtonActive: {
    backgroundColor: colors.dark.card,
  },
  toggleButtonText: {
    fontSize: 16,
    color: colors.dark.textSecondary,
  },
  toggleButtonTextActive: {
    color: colors.dark.text,
    fontWeight: '600',
  },
  resultsContainer: {
    marginBottom: 16,
  },
  section: {
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginLeft: 8,
  },
  settlementsContainer: {
    marginBottom: 16,
  },
  settlementHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  settlementTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  markAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 16,
  },
  markAllText: {
    color: colors.dark.primary,
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  paymentInstructions: {
    marginBottom: 16,
    backgroundColor: colors.dark.cardAlt,
    borderLeftWidth: 4,
    borderLeftColor: colors.dark.primary,
  },
  instructionsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  instructionsText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    lineHeight: 20,
  },
  emptyCard: {
    padding: 24,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyMessage: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    textAlign: 'center',
  },
  backButton: {
    marginBottom: 24,
  },
});