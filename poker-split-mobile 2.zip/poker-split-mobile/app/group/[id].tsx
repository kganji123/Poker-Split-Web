import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { 
  Users, 
  Plus, 
  Settings, 
  Trash2, 
  DollarSign,
  Calendar,
  ChevronRight,
  UserPlus
} from 'lucide-react-native';
import colors from '@/constants/colors';
import useStore from '@/store/useStore';
import Card from '@/components/Card';
import Button from '@/components/Button';
import Avatar from '@/components/Avatar';
import EmptyState from '@/components/EmptyState';
import AddPlayerModal from '@/components/AddPlayerModal';

export default function GroupDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user, groups, games, deleteGroup, createGame, updateGroup } = useStore();
  const [showSettings, setShowSettings] = useState(false);
  const [showAddPlayerModal, setShowAddPlayerModal] = useState(false);
  
  if (!id || !user) return null;
  
  const group = groups.find(g => g.id === id);
  if (!group) {
    // Use setTimeout to avoid navigation during render
    setTimeout(() => {
      router.back();
    }, 0);
    return null;
  }
  
  const isAdmin = group.adminId === user.id;
  const groupGames = games.filter(game => game.groupId === id)
    .sort((a, b) => b.date - a.date);
  
  const activeGames = groupGames.filter(game => game.isActive);
  const completedGames = groupGames.filter(game => !game.isActive);
  
  const handleStartNewGame = () => {
    router.push({
      pathname: '/game/create',
      params: { groupId: id }
    });
  };
  
  const handleDeleteGroup = () => {
    Alert.alert(
      "Delete Group",
      "Are you sure you want to delete this group? All associated games and data will be lost.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Delete", 
          onPress: () => {
            deleteGroup(id);
            router.back();
          },
          style: "destructive"
        }
      ]
    );
  };

  const handleAddPlayer = (name: string, email?: string) => {
    // In a real app, you would create a user account or invite via email
    // For this demo, we'll create a dummy user ID
    const newPlayerId = `player-${Date.now()}`;
    
    // Add the player to the group's members array
    const updatedMembers = [...group.members, newPlayerId];
    updateGroup(id, { members: updatedMembers });
    
    Alert.alert("Success", `${name} has been added to the group`);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <Stack.Screen 
        options={{
          title: group.name,
          headerRight: () => (
            isAdmin ? (
              <TouchableOpacity 
                onPress={() => setShowSettings(!showSettings)}
                style={styles.headerButton}
              >
                <Settings size={24} color={colors.dark.text} />
              </TouchableOpacity>
            ) : null
          ),
        }} 
      />
      
      {/* Group Info Card */}
      <Card style={styles.infoCard}>
        <View style={styles.infoRow}>
          <View style={styles.infoIconContainer}>
            <DollarSign size={20} color={colors.dark.primary} />
          </View>
          <Text style={styles.infoLabel}>Chip Value:</Text>
          <Text style={styles.infoValue}>${group.chipValue} per 1000 chips</Text>
        </View>
        
        <View style={styles.infoRow}>
          <View style={styles.infoIconContainer}>
            <Users size={20} color={colors.dark.primary} />
          </View>
          <Text style={styles.infoLabel}>Members:</Text>
          <Text style={styles.infoValue}>{group.members.length}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <View style={styles.infoIconContainer}>
            <Calendar size={20} color={colors.dark.primary} />
          </View>
          <Text style={styles.infoLabel}>Created:</Text>
          <Text style={styles.infoValue}>
            {new Date(group.createdAt).toLocaleDateString()}
          </Text>
        </View>
      </Card>
      
      {/* Settings Panel (Admin only) */}
      {showSettings && isAdmin && (
        <Card style={styles.settingsCard}>
          <Text style={styles.settingsTitle}>Group Settings</Text>
          
          <TouchableOpacity 
            style={styles.settingsOption}
            onPress={() => {
              // In a real app, navigate to edit group screen
              Alert.alert("Edit Group", "This feature would allow editing the group details.");
            }}
          >
            <Settings size={20} color={colors.dark.primary} />
            <Text style={styles.settingsOptionText}>Edit Group Details</Text>
            <ChevronRight size={16} color={colors.dark.textSecondary} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.settingsOption}
            onPress={() => setShowAddPlayerModal(true)}
          >
            <UserPlus size={20} color={colors.dark.primary} />
            <Text style={styles.settingsOptionText}>Add Player</Text>
            <ChevronRight size={16} color={colors.dark.textSecondary} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.settingsOption}
            onPress={() => {
              // In a real app, navigate to manage members screen
              Alert.alert("Manage Members", "This feature would allow managing group members.");
            }}
          >
            <Users size={20} color={colors.dark.primary} />
            <Text style={styles.settingsOptionText}>Manage Members</Text>
            <ChevronRight size={16} color={colors.dark.textSecondary} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.settingsOption, styles.deleteOption]}
            onPress={handleDeleteGroup}
          >
            <Trash2 size={20} color={colors.dark.error} />
            <Text style={[styles.settingsOptionText, styles.deleteText]}>Delete Group</Text>
          </TouchableOpacity>
        </Card>
      )}
      
      {/* Members Section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Members</Text>
          {isAdmin && (
            <TouchableOpacity 
              style={styles.newButton}
              onPress={() => setShowAddPlayerModal(true)}
            >
              <UserPlus size={16} color={colors.dark.primary} />
              <Text style={styles.newButtonText}>Add Player</Text>
            </TouchableOpacity>
          )}
        </View>
        
        <Card style={styles.membersCard}>
          <View style={styles.membersList}>
            {/* In a real app, you would fetch user details for each member ID */}
            {/* For this demo, we'll show the current user and dummy members */}
            <View style={styles.memberItem}>
              <Avatar name={user.name} imageUrl={user.avatar} size={40} />
              <View style={styles.memberInfo}>
                <Text style={styles.memberName}>{user.name}</Text>
                {group.adminId === user.id && (
                  <View style={styles.adminBadge}>
                    <Text style={styles.adminBadgeText}>Admin</Text>
                  </View>
                )}
              </View>
            </View>
            
            {/* Add dummy members for demo purposes */}
            {group.members.length > 1 && Array.from({ length: group.members.length - 1 }).map((_, index) => (
              <View key={index} style={styles.memberItem}>
                <Avatar name={`Player ${index + 2}`} size={40} />
                <View style={styles.memberInfo}>
                  <Text style={styles.memberName}>{`Player ${index + 2}`}</Text>
                </View>
              </View>
            ))}
          </View>
        </Card>
      </View>
      
      {/* Active Games Section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Active Games</Text>
          <TouchableOpacity 
            style={styles.newButton}
            onPress={handleStartNewGame}
          >
            <Plus size={16} color={colors.dark.primary} />
            <Text style={styles.newButtonText}>New Game</Text>
          </TouchableOpacity>
        </View>
        
        {activeGames.length > 0 ? (
          activeGames.map(game => (
            <Card key={game.id} style={styles.gameCard}>
              <TouchableOpacity 
                style={styles.gameCardContent}
                onPress={() => router.push(`/game/${game.id}`)}
              >
                <View style={styles.gameInfo}>
                  <Text style={styles.gameName}>{game.name}</Text>
                  <Text style={styles.gameDate}>
                    {new Date(game.date).toLocaleDateString()}
                  </Text>
                  
                  <View style={styles.playerAvatars}>
                    {game.players.slice(0, 3).map((player, index) => (
                      <View key={player.userId} style={[
                        styles.avatarContainer,
                        { marginLeft: index > 0 ? -15 : 0 }
                      ]}>
                        <Avatar 
                          name={player.name} 
                          imageUrl={player.avatar} 
                          size={30} 
                        />
                      </View>
                    ))}
                    
                    {game.players.length > 3 && (
                      <View style={[styles.avatarContainer, { marginLeft: -15 }]}>
                        <View style={styles.moreAvatars}>
                          <Text style={styles.moreAvatarsText}>
                            +{game.players.length - 3}
                          </Text>
                        </View>
                      </View>
                    )}
                  </View>
                </View>
                
                <View style={styles.continueButton}>
                  <Button 
                    title="Continue" 
                    onPress={() => router.push(`/game/${game.id}`)}
                    size="small"
                  />
                </View>
              </TouchableOpacity>
            </Card>
          ))
        ) : (
          <EmptyState
            title="No Active Games"
            message="Start a new poker game with this group."
            actionLabel="Start Game"
            onAction={handleStartNewGame}
          />
        )}
      </View>
      
      {/* Completed Games Section */}
      {completedGames.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Completed Games</Text>
          
          {completedGames.slice(0, 5).map(game => (
            <Card key={game.id} style={styles.completedGameCard}>
              <TouchableOpacity 
                style={styles.gameCardContent}
                onPress={() => router.push(`/game/${game.id}`)}
              >
                <View style={styles.gameInfo}>
                  <Text style={styles.gameName}>{game.name}</Text>
                  <Text style={styles.gameDate}>
                    {new Date(game.date).toLocaleDateString()}
                  </Text>
                  
                  <View style={styles.playerAvatars}>
                    {game.players.slice(0, 3).map((player, index) => (
                      <View key={player.userId} style={[
                        styles.avatarContainer,
                        { marginLeft: index > 0 ? -15 : 0 }
                      ]}>
                        <Avatar 
                          name={player.name} 
                          imageUrl={player.avatar} 
                          size={30} 
                        />
                      </View>
                    ))}
                    
                    {game.players.length > 3 && (
                      <View style={[styles.avatarContainer, { marginLeft: -15 }]}>
                        <View style={styles.moreAvatars}>
                          <Text style={styles.moreAvatarsText}>
                            +{game.players.length - 3}
                          </Text>
                        </View>
                      </View>
                    )}
                  </View>
                </View>
                
                <ChevronRight size={20} color={colors.dark.textSecondary} />
              </TouchableOpacity>
            </Card>
          ))}
          
          {completedGames.length > 5 && (
            <TouchableOpacity style={styles.viewAllButton}>
              <Text style={styles.viewAllText}>View All Games</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
      
      {/* Add Player Modal */}
      <AddPlayerModal
        visible={showAddPlayerModal}
        onClose={() => setShowAddPlayerModal(false)}
        onAddPlayer={handleAddPlayer}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
  },
  headerButton: {
    padding: 8,
  },
  infoCard: {
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.dark.cardAlt,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  infoLabel: {
    fontSize: 16,
    color: colors.dark.textSecondary,
    width: 100,
  },
  infoValue: {
    fontSize: 16,
    color: colors.dark.text,
    fontWeight: '500',
    flex: 1,
  },
  settingsCard: {
    marginBottom: 16,
  },
  settingsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  settingsOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  settingsOptionText: {
    fontSize: 16,
    color: colors.dark.text,
    flex: 1,
    marginLeft: 12,
  },
  deleteOption: {
    borderBottomWidth: 0,
    marginTop: 8,
  },
  deleteText: {
    color: colors.dark.error,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  newButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  newButtonText: {
    color: colors.dark.primary,
    marginLeft: 4,
    fontWeight: '500',
  },
  membersCard: {
    padding: 0,
  },
  membersList: {
    padding: 8,
  },
  memberItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  memberItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
  },
  memberInfo: {
    marginLeft: 12,
    flex: 1,
  },
  memberName: {
    fontSize: 16,
    color: colors.dark.text,
    fontWeight: '500',
  },
  adminBadge: {
    backgroundColor: colors.dark.primary,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: 'flex-start',
    marginTop: 4,
  },
  adminBadgeText: {
    color: colors.dark.background,
    fontSize: 12,
    fontWeight: '600',
  },
  gameCard: {
    marginBottom: 12,
  },
  completedGameCard: {
    marginBottom: 8,
    opacity: 0.9,
  },
  gameCardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  gameInfo: {
    flex: 1,
  },
  gameName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  gameDate: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    marginBottom: 8,
  },
  playerAvatars: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    zIndex: 1,
  },
  moreAvatars: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.dark.cardAlt,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  moreAvatarsText: {
    fontSize: 12,
    color: colors.dark.textSecondary,
    fontWeight: 'bold',
  },
  continueButton: {
    marginLeft: 12,
  },
  viewAllButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  viewAllText: {
    color: colors.dark.primary,
    fontSize: 16,
    fontWeight: '500',
  },
});