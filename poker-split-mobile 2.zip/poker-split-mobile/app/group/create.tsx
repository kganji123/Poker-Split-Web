import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { router } from 'expo-router';
import { Users, DollarSign } from 'lucide-react-native';
import colors from '@/constants/colors';
import Input from '@/components/Input';
import Button from '@/components/Button';
import useStore from '@/store/useStore';

export default function CreateGroupScreen() {
  const { user, createGroup } = useStore();
  const [name, setName] = useState('');
  const [chipValue, setChipValue] = useState('5');
  const [loading, setLoading] = useState(false);
  
  // Use a state to track if we should redirect
  const [shouldRedirect, setShouldRedirect] = useState(false);

  useEffect(() => {
    // Set a flag instead of redirecting immediately
    if (!user) {
      setShouldRedirect(true);
    }
  }, [user]);

  // Only redirect after component is mounted
  useEffect(() => {
    if (shouldRedirect) {
      // Use a small timeout to ensure layout is mounted
      const timer = setTimeout(() => {
        router.replace('/(auth)/login');
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [shouldRedirect]);
  
  if (!user) return null;

  const handleCreateGroup = () => {
    if (!name.trim()) {
      alert('Please enter a group name');
      return;
    }
    
    const chipValueNum = parseFloat(chipValue);
    if (isNaN(chipValueNum) || chipValueNum <= 0) {
      alert('Please enter a valid chip value');
      return;
    }
    
    setLoading(true);
    
    // Create the group
    createGroup({
      name: name.trim(),
      adminId: user.id,
      chipValue: chipValueNum,
      members: [user.id],
      buyInAmount: 2000, // Default buy-in amount of 2000 chips
    });
    
    setLoading(false);
    router.back();
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.title}>Create a Poker Group</Text>
          <Text style={styles.subtitle}>Set up a group for your poker games</Text>
        </View>
        
        <View style={styles.formContainer}>
          <Input
            label="Group Name"
            value={name}
            onChangeText={setName}
            placeholder="Enter group name"
            leftIcon={<Users size={20} color={colors.dark.textSecondary} />}
          />
          
          <Input
            label="Chip Value ($ per 1000 chips)"
            value={chipValue}
            onChangeText={setChipValue}
            placeholder="Enter chip value"
            keyboardType="numeric"
            leftIcon={<DollarSign size={20} color={colors.dark.textSecondary} />}
          />
          
          <View style={styles.infoBox}>
            <Text style={styles.infoTitle}>About Chip Value</Text>
            <Text style={styles.infoText}>
              Enter the dollar value of 1000 chips. Default is $5 for 2000 chips, which means $2.5 per 1000 chips.
            </Text>
          </View>
          
          <Button
            title="Create Group"
            onPress={handleCreateGroup}
            loading={loading}
            style={styles.createButton}
          />
          
          <Button
            title="Cancel"
            onPress={() => router.back()}
            variant="ghost"
            disabled={loading}
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  scrollContent: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.dark.textSecondary,
  },
  formContainer: {
    marginBottom: 24,
  },
  infoBox: {
    backgroundColor: colors.dark.cardAlt,
    borderRadius: 8,
    padding: 16,
    marginBottom: 24,
    borderLeftWidth: 4,
    borderLeftColor: colors.dark.primary,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: colors.dark.textSecondary,
    lineHeight: 20,
  },
  createButton: {
    marginBottom: 12,
  },
});