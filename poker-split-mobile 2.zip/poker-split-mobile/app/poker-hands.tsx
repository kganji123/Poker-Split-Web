import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';
import { Stack } from 'expo-router';
import colors from '@/constants/colors';
import Card from '@/components/Card';

export default function PokerHandsScreen() {
  const pokerHands = [
    {
      name: 'Royal Flush',
      description: 'A, K, Q, J, 10, all the same suit.',
      example: '10♥ J♥ Q♥ K♥ A♥',
      rank: 1,
    },
    {
      name: 'Straight Flush',
      description: 'Five cards in a sequence, all in the same suit.',
      example: '5♣ 6♣ 7♣ 8♣ 9♣',
      rank: 2,
    },
    {
      name: 'Four of a Kind',
      description: 'All four cards of the same rank.',
      example: 'J♥ J♦ J♣ J♠ 7♥',
      rank: 3,
    },
    {
      name: 'Full House',
      description: 'Three of a kind with a pair.',
      example: '10♥ 10♦ 10♣ 9♥ 9♠',
      rank: 4,
    },
    {
      name: 'Flush',
      description: 'Any five cards of the same suit, but not in a sequence.',
      example: '2♥ 5♥ 7♥ 9♥ K♥',
      rank: 5,
    },
    {
      name: 'Straight',
      description: 'Five cards in a sequence, but not of the same suit.',
      example: '6♥ 7♦ 8♣ 9♠ 10♥',
      rank: 6,
    },
    {
      name: 'Three of a Kind',
      description: 'Three cards of the same rank.',
      example: '8♥ 8♦ 8♣ 4♠ 7♥',
      rank: 7,
    },
    {
      name: 'Two Pair',
      description: 'Two different pairs.',
      example: 'J♥ J♦ 3♣ 3♠ A♥',
      rank: 8,
    },
    {
      name: 'Pair',
      description: 'Two cards of the same rank.',
      example: '10♥ 10♦ 5♣ 8♠ A♥',
      rank: 9,
    },
    {
      name: 'High Card',
      description: 'When you haven not made any of the hands above, the highest card plays.',
      example: 'A♥ J♦ 8♣ 7♠ 3♥',
      rank: 10,
    },
  ];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <Stack.Screen options={{ title: 'Poker Hands' }} />
      
      <View style={styles.header}>
        <Text style={styles.title}>Poker Hand Rankings</Text>
        <Text style={styles.subtitle}>From strongest (1) to weakest (10)</Text>
      </View>
      
      {pokerHands.map((hand) => (
        <Card key={hand.name} style={styles.handCard}>
          <View style={styles.rankBadge}>
            <Text style={styles.rankText}>{hand.rank}</Text>
          </View>
          
          <Text style={styles.handName}>{hand.name}</Text>
          <Text style={styles.handDescription}>{hand.description}</Text>
          
          <View style={styles.exampleContainer}>
            <Text style={styles.exampleLabel}>Example:</Text>
            <Text style={styles.exampleText}>{hand.example}</Text>
          </View>
          
          <View style={styles.cardVisual}>
            {hand.example.split(' ').map((card, index) => {
              const value = card.slice(0, -1);
              const suit = card.slice(-1);
              const suitColor = suit === '♥' || suit === '♦' ? '#D32F2F' : '#000000';
              
              return (
                <View key={index} style={styles.card}>
                  <Text style={[styles.cardValue, { color: suitColor }]}>{value}</Text>
                  <Text style={[styles.cardSuit, { color: suitColor }]}>{suit}</Text>
                </View>
              );
            })}
          </View>
        </Card>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    marginBottom: 24,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.dark.textSecondary,
  },
  handCard: {
    marginBottom: 16,
    position: 'relative',
    paddingTop: 24,
  },
  rankBadge: {
    position: 'absolute',
    top: -10,
    right: 16,
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rankText: {
    color: colors.dark.background,
    fontWeight: 'bold',
    fontSize: 16,
  },
  handName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  handDescription: {
    fontSize: 16,
    color: colors.dark.textSecondary,
    marginBottom: 16,
    lineHeight: 22,
  },
  exampleContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  exampleLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginRight: 8,
  },
  exampleText: {
    fontSize: 16,
    color: colors.dark.text,
  },
  cardVisual: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  card: {
    width: 50,
    height: 70,
    backgroundColor: '#FFFFFF',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
    elevation: 3,
  },
  cardValue: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cardSuit: {
    fontSize: 24,
    marginTop: -5,
  },
});