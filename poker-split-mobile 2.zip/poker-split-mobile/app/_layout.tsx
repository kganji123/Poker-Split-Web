import FontAwesome from "@expo/vector-icons/FontAwesome";
import { useFonts } from "expo-font";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import { StatusBar } from "expo-status-bar";
import { Platform, TouchableOpacity } from "react-native";
import { ErrorBoundary } from "./error-boundary";
import colors from "@/constants/colors";
import { HelpCircle } from "lucide-react-native";
import { router } from "expo-router";

export const unstable_settings = {
  initialRouteName: "(tabs)",
};

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded, error] = useFonts({
    ...FontAwesome.font,
  });

  useEffect(() => {
    if (error) {
      console.error(error);
      throw error;
    }
  }, [error]);

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return (
    <ErrorBoundary>
      <StatusBar style="light" />
      <RootLayoutNav />
    </ErrorBoundary>
  );
}

function RootLayoutNav() {
  return (
    <Stack
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.dark.background,
        },
        headerTintColor: colors.dark.text,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        contentStyle: {
          backgroundColor: colors.dark.background,
        },
        headerRight: () => (
          <TouchableOpacity 
            onPress={() => router.push('/poker-hands')}
            style={{ marginRight: 10 }}
          >
            <HelpCircle size={24} color={colors.dark.text} />
          </TouchableOpacity>
        ),
      }}
    >
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen 
        name="(auth)/login" 
        options={{ 
          headerShown: false,
          presentation: 'modal',
        }} 
      />
      <Stack.Screen 
        name="(auth)/register" 
        options={{ 
          headerShown: false,
          presentation: 'modal',
        }} 
      />
      <Stack.Screen 
        name="group/create" 
        options={{ 
          title: "Create Group",
          animation: 'slide_from_right',
        }} 
      />
      <Stack.Screen 
        name="group/[id]" 
        options={{ 
          title: "Group Details",
          animation: 'slide_from_right',
        }} 
      />
      <Stack.Screen 
        name="game/create" 
        options={{ 
          title: "New Game",
          animation: 'slide_from_right',
        }} 
      />
      <Stack.Screen 
        name="game/[id]" 
        options={{ 
          title: "Game Details",
          animation: 'slide_from_right',
        }} 
      />
      <Stack.Screen 
        name="game/[id]/player/[playerId]" 
        options={{ 
          title: "Player Details",
          animation: 'slide_from_right',
        }} 
      />
      <Stack.Screen 
        name="game/[id]/settlements" 
        options={{ 
          title: "Settlements",
          animation: 'slide_from_right',
        }} 
      />
      <Stack.Screen 
        name="poker-hands" 
        options={{ 
          title: "Poker Hands",
          animation: 'slide_from_right',
        }} 
      />
    </Stack>
  );
}