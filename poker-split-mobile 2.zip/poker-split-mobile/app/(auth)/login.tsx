import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { Mail, Lock, ChevronRight } from 'lucide-react-native';
import colors from '@/constants/colors';
import Input from '@/components/Input';
import Button from '@/components/Button';
import useStore from '@/store/useStore';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { setUser } = useStore();

  const handleLogin = () => {
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      // In a real app, you would validate credentials with an API
      setUser({
        id: '1',
        name: 'John Doe',
        email: email || 'john.doe@example.com',
      });
      
      setLoading(false);
      // Use setTimeout to avoid navigation during render
      setTimeout(() => {
        router.replace('/');
      }, 0);
    }, 1000);
  };

  const handleDemoLogin = () => {
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setUser({
        id: '1',
        name: 'Demo User',
        email: 'demo@example.com',
      });
      
      setLoading(false);
      // Use setTimeout to avoid navigation during render
      setTimeout(() => {
        router.replace('/');
      }, 0);
    }, 1000);
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View style={styles.logoContainer}>
            <View style={styles.logoCircle}>
              <View style={styles.chipStack}>
                <View style={[styles.chip, styles.chipRed]} />
                <View style={[styles.chip, styles.chipBlue, styles.chipOffset]} />
                <View style={[styles.chip, styles.chipBlack, styles.chipOffset2]} />
              </View>
            </View>
          </View>
          <Text style={styles.title}>Poker Split</Text>
          <Text style={styles.subtitle}>Settle poker debts with ease</Text>
        </View>
        
        <View style={styles.formContainer}>
          <Input
            label="Email"
            value={email}
            onChangeText={setEmail}
            placeholder="Enter your email"
            keyboardType="email-address"
            leftIcon={<Mail size={20} color={colors.dark.textSecondary} />}
          />
          
          <Input
            label="Password"
            value={password}
            onChangeText={setPassword}
            placeholder="Enter your password"
            secureTextEntry
            leftIcon={<Lock size={20} color={colors.dark.textSecondary} />}
          />
          
          <TouchableOpacity style={styles.forgotPassword}>
            <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
          </TouchableOpacity>
          
          <Button
            title="Login"
            onPress={handleLogin}
            loading={loading}
            style={styles.loginButton}
          />
          
          <Button
            title="Demo Login"
            onPress={handleDemoLogin}
            variant="outline"
            loading={loading}
            style={styles.demoButton}
          />
        </View>
        
        <View style={styles.footer}>
          <Text style={styles.footerText}>Don't have an account?</Text>
          <TouchableOpacity 
            style={styles.registerButton}
            onPress={() => router.push('/(auth)/register')}
          >
            <Text style={styles.registerButtonText}>Register</Text>
            <ChevronRight size={16} color={colors.dark.primary} />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 24,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 48,
  },
  logoContainer: {
    marginBottom: 16,
  },
  logoCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.dark.card,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chipStack: {
    position: 'relative',
    width: 60,
    height: 60,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chip: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: colors.dark.text,
    position: 'absolute',
  },
  chipRed: {
    backgroundColor: colors.dark.chipRed,
    zIndex: 1,
  },
  chipBlue: {
    backgroundColor: colors.dark.chipBlue,
    zIndex: 2,
  },
  chipBlack: {
    backgroundColor: colors.dark.chipBlack,
    zIndex: 3,
  },
  chipOffset: {
    top: -5,
    left: 5,
  },
  chipOffset2: {
    top: -10,
    left: 0,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.dark.textSecondary,
    textAlign: 'center',
  },
  formContainer: {
    marginBottom: 24,
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginBottom: 24,
  },
  forgotPasswordText: {
    color: colors.dark.primary,
    fontSize: 14,
  },
  loginButton: {
    marginBottom: 12,
  },
  demoButton: {
    marginBottom: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  footerText: {
    color: colors.dark.textSecondary,
    marginRight: 8,
  },
  registerButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  registerButtonText: {
    color: colors.dark.primary,
    fontWeight: '600',
  },
});